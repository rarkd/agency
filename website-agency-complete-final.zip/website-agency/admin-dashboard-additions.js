// ============================================
// TAMBAHAN UNTUK admin.js
// ============================================

// GLOBAL VARIABLES - Add at top
let currentChatUserId = null;

// ADD TO DOMContentLoaded:
document.addEventListener('DOMContentLoaded', () => {
    loadStats();
    loadContacts();
    loadOrders();
    loadPortfolios();
    loadUsers();        // NEW
    loadAdminChats();   // NEW
    
    setupTechInput();
    
    // NEW: Auto-refresh chats every 5 seconds
    setInterval(() => {
        if (currentChatUserId) {
            loadAdminChats();
        }
    }, 5000);
});

// NEW FUNCTION: Load users
async function loadUsers() {
    try {
        const response = await fetch('/api/admin/users');
        const users = await response.json();
        
        const tbody = document.getElementById('usersTableBody');
        
        if (users.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="empty-state">No users yet</td></tr>';
            return;
        }
        
        tbody.innerHTML = users.map(user => `
            <tr>
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td>${user.phone}</td>
                <td>${new Date(user.createdAt).toLocaleDateString('id-ID')}</td>
                <td>
                    <div class="action-btns">
                        <button class="action-btn btn-delete" onclick="deleteUser(${user.id})">Delete</button>
                    </div>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading users:', error);
    }
}

// NEW FUNCTION: Delete user
async function deleteUser(id) {
    if (!confirm('Are you sure you want to delete this user? This will also delete all their orders and messages.')) return;
    
    try {
        const response = await fetch(`/api/admin/users/${id}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            loadUsers();
            loadStats();
            alert('User deleted successfully!');
        }
    } catch (error) {
        console.error('Error deleting user:', error);
        alert('Error deleting user');
    }
}

// NEW FUNCTION: Load admin chats
async function loadAdminChats() {
    try {
        const response = await fetch('/api/admin/chats');
        const chatsByUser = await response.json();
        
        const chatList = document.getElementById('chatUserList');
        
        if (chatsByUser.length === 0) {
            chatList.innerHTML = '<div class="empty-state">No chats yet</div>';
            return;
        }
        
        chatList.innerHTML = chatsByUser.map(chat => `
            <div class="chat-user-item ${currentChatUserId === chat.userId ? 'active' : ''}" 
                 onclick="openUserChat(${chat.userId})">
                <div class="chat-user-name">
                    ${chat.userName}
                    ${chat.unreadCount > 0 ? `<span class="chat-unread">${chat.unreadCount}</span>` : ''}
                </div>
                <div class="chat-user-email">${chat.userEmail}</div>
            </div>
        `).join('');
        
        // If a chat is open, refresh messages
        if (currentChatUserId) {
            const userChat = chatsByUser.find(c => c.userId === currentChatUserId);
            if (userChat) {
                displayChatMessages(userChat);
            }
        }
    } catch (error) {
        console.error('Error loading chats:', error);
    }
}

// NEW FUNCTION: Open user chat
async function openUserChat(userId) {
    currentChatUserId = userId;
    
    // Mark as read
    await fetch(`/api/admin/chats/${userId}/read`, { method: 'PUT' });
    
    // Reload to update UI
    loadAdminChats();
    
    // Show input
    document.getElementById('adminChatInput').style.display = 'block';
}

// NEW FUNCTION: Display chat messages
function displayChatMessages(userChat) {
    const header = document.getElementById('adminChatHeader');
    const messages = document.getElementById('adminChatMessages');
    
    header.innerHTML = `
        <h3 style="margin: 0;">${userChat.userName}</h3>
        <p style="color: #666; font-size: 14px; margin: 5px 0 0 0;">${userChat.userEmail}</p>
    `;
    
    if (userChat.messages.length === 0) {
        messages.innerHTML = '<div class="empty-state">No messages yet</div>';
        return;
    }
    
    messages.innerHTML = userChat.messages.map(msg => `
        <div class="admin-chat-message ${msg.sender}">
            <div style="font-weight: 600; font-size: 12px; margin-bottom: 5px; opacity: 0.8;">
                ${msg.sender === 'user' ? userChat.userName : 'You (Admin)'}
            </div>
            <div>${msg.message}</div>
            <div style="font-size: 11px; opacity: 0.7; margin-top: 5px;">
                ${new Date(msg.timestamp).toLocaleString('id-ID', {
                    hour: '2-digit',
                    minute: '2-digit',
                    month: 'short',
                    day: 'numeric'
                })}
            </div>
        </div>
    `).join('');
    
    // Scroll to bottom
    messages.scrollTop = messages.scrollHeight;
}

// NEW FUNCTION: Send admin message
async function sendAdminMessage() {
    if (!currentChatUserId) return;
    
    const input = document.getElementById('adminMessageInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    try {
        const response = await fetch('/api/admin/chats', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userId: currentChatUserId,
                message: message
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            input.value = '';
            loadAdminChats();
        }
    } catch (error) {
        console.error('Error sending message:', error);
        alert('Failed to send message');
    }
}

// UPDATE FUNCTION: Enhanced loadOrders to show phone and template
async function loadOrders() {
    try {
        const response = await fetch('/api/admin/orders');
        const orders = await response.json();
        
        const tbody = document.getElementById('ordersTableBody');
        
        if (orders.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="empty-state">No orders yet</td></tr>';
            return;
        }
        
        tbody.innerHTML = orders.map(order => `
            <tr>
                <td>${new Date(order.timestamp).toLocaleDateString('id-ID')}</td>
                <td>${order.name}</td>
                <td><strong>${order.phone}</strong></td>
                <td>${order.package}</td>
                <td>${order.template ? 
                    `<span class="template-badge">${order.template.title}</span>` : 
                    '-'}</td>
                <td><span class="status-badge status-${order.status}">${order.status}</span></td>
                <td>
                    <div class="action-btns">
                        <button class="action-btn btn-edit" onclick="viewOrder(${order.id})">View</button>
                    </div>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading orders:', error);
    }
}

// UPDATE FUNCTION: Enhanced viewOrder to show full details
async function viewOrder(id) {
    try {
        const response = await fetch('/api/admin/orders');
        const orders = await response.json();
        const order = orders.find(o => o.id === id);
        
        currentOrderId = id;
        
        document.getElementById('orderDetails').innerHTML = `
            <div class="form-group">
                <label>Name:</label>
                <p><strong>${order.name}</strong></p>
            </div>
            <div class="form-group">
                <label>Email:</label>
                <p>${order.email}</p>
            </div>
            <div class="form-group">
                <label>Phone:</label>
                <p><strong style="color: #667eea;">${order.phone}</strong></p>
            </div>
            <div class="form-group">
                <label>Package:</label>
                <p><strong>${order.package.toUpperCase()}</strong></p>
            </div>
            ${order.template ? `
            <div class="form-group">
                <label>Template Reference:</label>
                <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin-top: 10px;">
                    <p style="margin-bottom: 10px;"><strong>${order.template.title}</strong></p>
                    <a href="${order.template.previewUrl}" target="_blank" 
                       style="color: #667eea; text-decoration: none; font-weight: 600;">
                        👁️ View Template Preview →
                    </a>
                </div>
            </div>
            ` : `
            <div class="form-group">
                <label>Template Reference:</label>
                <p style="color: #999;">No template selected</p>
            </div>
            `}
            <div class="form-group">
                <label>Requirements:</label>
                <p style="background: #f9f9f9; padding: 15px; border-radius: 5px; white-space: pre-wrap;">${order.requirements}</p>
            </div>
            <div class="form-group">
                <label>Date:</label>
                <p>${new Date(order.timestamp).toLocaleString('id-ID')}</p>
            </div>
        `;
        
        document.getElementById('orderStatus').value = order.status;
        
        openModal('orderModal');
    } catch (error) {
        console.error('Error viewing order:', error);
    }
}
