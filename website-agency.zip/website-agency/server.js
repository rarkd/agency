require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const admin = require('firebase-admin');

const app = express();
const PORT = process.env.PORT || 3000;

// Firebase Admin initialization
// Uncomment dan configure dengan service account key Anda
/*
const serviceAccount = require('./config/firebase-service-account.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://your-project-id.firebaseio.com"
});
const db = admin.firestore();
*/

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Data contoh website portfolio
const portfolioWebsites = [
  {
    id: 1,
    title: "E-Commerce Fashion Store",
    category: "E-Commerce",
    description: "Toko online fashion modern dengan sistem pembayaran terintegrasi",
    image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&h=600&fit=crop",
    technologies: ["Node.js", "React", "MongoDB", "Stripe"],
    package: "gold"
  },
  {
    id: 2,
    title: "Restaurant Landing Page",
    category: "Landing Page",
    description: "Website landing page elegant untuk restaurant dengan online booking",
    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&h=600&fit=crop",
    technologies: ["HTML", "CSS", "JavaScript"],
    package: "bronze"
  },
  {
    id: 3,
    title: "Corporate Business Portal",
    category: "Corporate",
    description: "Portal perusahaan dengan manajemen konten dan admin dashboard",
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&h=600&fit=crop",
    technologies: ["Node.js", "Express", "MySQL", "Bootstrap"],
    package: "silver"
  },
  {
    id: 4,
    title: "Real Estate Platform",
    category: "Platform",
    description: "Platform listing properti dengan pencarian advanced dan maps",
    image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&h=600&fit=crop",
    technologies: ["Node.js", "Vue.js", "PostgreSQL", "Google Maps API"],
    package: "gold"
  },
  {
    id: 5,
    title: "Personal Portfolio",
    category: "Portfolio",
    description: "Website portfolio personal yang minimalis dan modern",
    image: "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=800&h=600&fit=crop",
    technologies: ["HTML", "CSS", "JavaScript", "GSAP"],
    package: "bronze"
  },
  {
    id: 6,
    title: "Healthcare Appointment System",
    category: "Web App",
    description: "Sistem booking appointment untuk klinik dengan notifikasi real-time",
    image: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800&h=600&fit=crop",
    technologies: ["Node.js", "React", "MySQL", "Socket.io"],
    package: "silver"
  },
  {
    id: 7,
    title: "Educational Learning Platform",
    category: "E-Learning",
    description: "Platform pembelajaran online dengan video streaming dan quiz interaktif",
    image: "https://images.unsplash.com/photo-1501504905252-473c47e087f8?w=800&h=600&fit=crop",
    technologies: ["Node.js", "Angular", "MongoDB", "AWS S3"],
    package: "gold"
  },
  {
    id: 8,
    title: "Travel Blog Website",
    category: "Blog",
    description: "Blog perjalanan dengan galeri foto dan integrasi social media",
    image: "https://images.unsplash.com/photo-1488085061387-422e29b40080?w=800&h=600&fit=crop",
    technologies: ["WordPress", "PHP", "MySQL"],
    package: "silver"
  }
];

// Data paket harga
const pricingPackages = [
  {
    id: 'bronze',
    name: 'Bronze',
    subtitle: 'Perfect untuk landing page',
    price: 'Rp 2.500.000',
    duration: 'one-time',
    features: [
      'Static Website (HTML, CSS, JS)',
      'Responsive Design',
      'Up to 5 Pages',
      'Contact Form',
      'Basic SEO Optimization',
      'Free Revisi 2x',
      'Source Code',
      '1 Bulan Support'
    ],
    highlight: false,
    color: '#CD7F32'
  },
  {
    id: 'silver',
    name: 'Silver',
    subtitle: 'Untuk website dinamis',
    price: 'Rp 8.500.000',
    duration: 'one-time',
    features: [
      'Dynamic Website (Node.js)',
      'MySQL Database',
      'Admin Dashboard',
      'Up to 15 Pages',
      'User Authentication',
      'Content Management System',
      'API Integration',
      'Advanced SEO',
      'Free Revisi 3x',
      'Source Code',
      '3 Bulan Support'
    ],
    highlight: true,
    color: '#C0C0C0'
  },
  {
    id: 'gold',
    name: 'Gold',
    subtitle: 'Solusi lengkap & premium',
    price: 'Rp 15.000.000',
    duration: 'one-time',
    features: [
      'Dynamic Website (Node.js)',
      'MySQL Database',
      'Advanced Admin Panel',
      'Unlimited Pages',
      'User Role Management',
      'Payment Gateway Integration',
      'Real-time Features (Socket.io)',
      'Cloud Hosting 1 Tahun',
      'Custom Domain (.com/.id)',
      'SSL Certificate',
      'Daily Backup',
      'Email Setup',
      'Advanced SEO & Analytics',
      'Free Revisi 5x',
      'Source Code',
      '6 Bulan Support + Maintenance'
    ],
    highlight: false,
    color: '#FFD700'
  }
];

// Routes
app.get('/', (req, res) => {
  res.render('index', { 
    portfolios: portfolioWebsites.slice(0, 6),
    packages: pricingPackages
  });
});

app.get('/portfolio', (req, res) => {
  res.render('portfolio', { portfolios: portfolioWebsites });
});

app.get('/pricing', (req, res) => {
  res.render('pricing', { packages: pricingPackages });
});

app.get('/contact', (req, res) => {
  res.render('contact');
});

// API Endpoints
app.get('/api/portfolios', (req, res) => {
  res.json(portfolioWebsites);
});

app.get('/api/packages', (req, res) => {
  res.json(pricingPackages);
});

// Contact form submission (with Firebase)
app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, phone, package: packageType, message } = req.body;
    
    // Uncomment untuk menyimpan ke Firebase
    /*
    await db.collection('contacts').add({
      name,
      email,
      phone,
      package: packageType,
      message,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    */
    
    console.log('Contact form submission:', { name, email, phone, packageType, message });
    
    res.json({ 
      success: true, 
      message: 'Terima kasih! Kami akan segera menghubungi Anda.' 
    });
  } catch (error) {
    console.error('Error saving contact:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Terjadi kesalahan. Silakan coba lagi.' 
    });
  }
});

// Order endpoint
app.post('/api/order', async (req, res) => {
  try {
    const { name, email, phone, package: packageType, requirements } = req.body;
    
    // Uncomment untuk menyimpan ke Firebase
    /*
    await db.collection('orders').add({
      name,
      email,
      phone,
      package: packageType,
      requirements,
      status: 'pending',
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    */
    
    console.log('Order submission:', { name, email, phone, packageType, requirements });
    
    res.json({ 
      success: true, 
      message: 'Order berhasil! Tim kami akan menghubungi Anda segera.' 
    });
  } catch (error) {
    console.error('Error saving order:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Terjadi kesalahan. Silakan coba lagi.' 
    });
  }
});

// 404 handler
app.use((req, res) => {
  res.status(404).render('404');
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});
