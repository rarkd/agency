#!/bin/bash

# Deployment Script for Website Agency
echo "🚀 Starting deployment..."

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js is not installed. Please install Node.js first.${NC}"
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ npm is not installed. Please install npm first.${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Node.js and npm are installed${NC}"

# Install dependencies
echo -e "${YELLOW}📦 Installing dependencies...${NC}"
npm install

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Failed to install dependencies${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Dependencies installed${NC}"

# Check if PM2 is installed
if ! command -v pm2 &> /dev/null; then
    echo -e "${YELLOW}📦 Installing PM2 globally...${NC}"
    sudo npm install -g pm2
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Failed to install PM2${NC}"
        exit 1
    fi
fi

echo -e "${GREEN}✓ PM2 is installed${NC}"

# Create logs directory
if [ ! -d "logs" ]; then
    echo -e "${YELLOW}📁 Creating logs directory...${NC}"
    mkdir logs
    echo -e "${GREEN}✓ Logs directory created${NC}"
fi

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo -e "${YELLOW}⚠️  .env file not found. Creating from template...${NC}"
    cp .env.example .env
    echo -e "${YELLOW}⚠️  Please edit .env file with your configurations${NC}"
fi

# Check if Firebase config exists
if [ ! -f "config/firebase-service-account.json" ]; then
    echo -e "${YELLOW}⚠️  Firebase service account not found.${NC}"
    echo -e "${YELLOW}   Please add your firebase-service-account.json to config/ directory${NC}"
fi

# Start with PM2
echo -e "${YELLOW}🚀 Starting application with PM2...${NC}"
pm2 start ecosystem.config.js

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Failed to start application${NC}"
    exit 1
fi

# Save PM2 configuration
pm2 save

echo -e "${GREEN}✓ Application started successfully${NC}"
echo -e "${GREEN}✓ PM2 configuration saved${NC}"

# Display status
echo -e "${YELLOW}📊 Application status:${NC}"
pm2 status

echo ""
echo -e "${GREEN}✅ Deployment completed successfully!${NC}"
echo ""
echo -e "${YELLOW}Useful commands:${NC}"
echo "  pm2 status              - Check application status"
echo "  pm2 logs website-agency - View application logs"
echo "  pm2 restart all         - Restart application"
echo "  pm2 stop all            - Stop application"
echo "  pm2 monit               - Monitor application"
echo ""
echo -e "${YELLOW}Access your website at: http://localhost:3000${NC}"
