# Website Agency - Static JSON Database Version

Website untuk jasa pembuatan website dengan admin dashboard management menggunakan static JSON database.

## 🔄 Perubahan dari Versi Sebelumnya

- ✅ Database menggunakan file JSON statis (`database.json`) menggantikan Firebase
- ✅ Port diubah menjadi **611**
- ✅ Admin dashboard lengkap untuk manajemen data
- ✅ Login system dengan session management
- ✅ CRUD operations untuk portfolios, contacts, dan orders

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Jalankan Server
```bash
npm start
```

atau untuk development dengan auto-reload:
```bash
npm run dev
```

Server akan berjalan di: **http://localhost:611**

## 👨‍💼 Admin Dashboard

### Akses Admin Panel
URL: **http://localhost:611/admin**

### Login Credentials
- **Username:** admin
- **Password:** admin123

> ⚠️ **Penting:** Ubah username dan password di file `database.json` untuk keamanan!

### Fitur Admin Dashboard

1. **Dashboard Statistics**
   - Total Contacts
   - Total Orders
   - Total Portfolios
   - Pending Orders

2. **Contact Management**
   - Lihat semua pesan contact
   - View detail kontak
   - Delete kontak

3. **Order Management**
   - Lihat semua orders
   - Update status order (pending, processing, completed)
   - View detail order lengkap
   - Delete order

4. **Portfolio Management**
   - Add portfolio baru
   - Edit portfolio existing
   - Delete portfolio
   - Manage technologies tags

## 📁 Struktur Database (database.json)

```json
{
  "portfolios": [...],      // Portfolio projects
  "packages": [...],        // Pricing packages
  "contacts": [],           // Contact form submissions
  "orders": [],             // Order submissions
  "admin": {
    "username": "admin",
    "password": "admin123"
  }
}
```

## 🔐 Keamanan

### Mengubah Admin Password
Edit file `database.json`:
```json
{
  "admin": {
    "username": "your-username",
    "password": "your-password"
  }
}
```

### Session Configuration
Edit di `server.js`:
```javascript
app.use(session({
  secret: 'your-secret-key-here',  // Ubah ini!
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 3600000 }
}));
```

> **Production:** Set `cookie.secure: true` jika menggunakan HTTPS

## 📝 API Endpoints

### Public Endpoints
- `GET /` - Homepage
- `GET /portfolio` - Portfolio page
- `GET /pricing` - Pricing page
- `GET /contact` - Contact page
- `POST /api/contact` - Submit contact form
- `POST /api/order` - Submit order
- `GET /api/portfolios` - Get all portfolios
- `GET /api/packages` - Get pricing packages

### Admin Endpoints (Requires Authentication)
- `GET /admin` - Admin dashboard
- `GET /admin/login` - Login page
- `POST /admin/login` - Login authentication
- `GET /admin/logout` - Logout
- `GET /api/admin/stats` - Dashboard statistics
- `GET /api/admin/contacts` - Get all contacts
- `GET /api/admin/orders` - Get all orders
- `POST /api/admin/portfolios` - Create portfolio
- `PUT /api/admin/portfolios/:id` - Update portfolio
- `DELETE /api/admin/portfolios/:id` - Delete portfolio
- `PUT /api/admin/contacts/:id` - Update contact
- `DELETE /api/admin/contacts/:id` - Delete contact
- `PUT /api/admin/orders/:id` - Update order
- `DELETE /api/admin/orders/:id` - Delete order

## 🛠️ Technologies

- **Backend:** Node.js + Express
- **Template Engine:** EJS
- **Database:** JSON file (static)
- **Session:** express-session
- **Frontend:** Vanilla JavaScript, CSS3

## 📦 Deployment

### Menggunakan PM2
```bash
npm install -g pm2
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

### Menggunakan Apache (Reverse Proxy)
Port 611 sudah dikonfigurasi di:
- `config/apache2-vhost.conf`
- File sudah diupdate untuk port 611

## 🔄 Backup Database

Database disimpan di file `database.json`. Untuk backup:
```bash
# Manual backup
cp database.json database.backup.json

# Automated backup (cron)
0 0 * * * cp /path/to/database.json /path/to/backups/database-$(date +\%Y\%m\%d).json
```

## 📱 Features

✅ Responsive design  
✅ Admin dashboard dengan authentication  
✅ Real-time data management  
✅ Contact form dengan database  
✅ Order management system  
✅ Portfolio CRUD operations  
✅ Session-based authentication  
✅ RESTful API  

## 🐛 Troubleshooting

### Port sudah digunakan
Ubah port di `.env`:
```
PORT=8080
```

### Session tidak tersimpan
Pastikan `express-session` terinstall:
```bash
npm install express-session
```

### Database tidak tersimpan
Check permissions file `database.json`:
```bash
chmod 644 database.json
```

## 📄 License

ISC

## 🤝 Support

Untuk pertanyaan atau support, hubungi admin@websiteagency.com
