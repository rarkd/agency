# 🚀 QUICK START GUIDE - Complete System

## ✨ Apa yang Ada di Sistem Ini?

### 1. 🌐 Website Public
- Homepage dengan portfolio showcase
- Portfolio page
- Pricing page
- Contact form
- Responsive design

### 2. 👨‍💼 Admin Dashboard
- **URL:** http://localhost:611/admin
- **Login:** username: `admin`, password: `admin123`
- Fitur:
  - View & manage contacts
  - View & manage orders (update status)
  - CRUD portfolios
  - Dashboard statistics

### 3. 👤 User Dashboard
- **Register:** http://localhost:611/user/register
- **Login:** http://localhost:611/user/login
- Fitur:
  - Register akun baru
  - Login ke dashboard pribadi
  - View orders & messages
  - Submit order baru
  - Send messages
  - Track order status

## 🎯 Setup dalam 3 Langkah:

```bash
# 1. Extract & Navigate
unzip website-agency-complete.zip
cd website-agency

# 2. Install Dependencies
npm install

# 3. Run Server
npm start
```

Server berjalan di: **http://localhost:611**

## 🔐 Login Credentials

### Admin Dashboard:
- URL: http://localhost:611/admin
- Username: `admin`
- Password: `admin123`

### User Dashboard:
- URL: http://localhost:611/user/register (Daftar baru)
- URL: http://localhost:611/user/login (Login)

## 📊 Database: database.json

```json
{
  "portfolios": [...],   // Portfolio projects
  "packages": [...],     // Pricing packages
  "contacts": [],        // Contact submissions
  "orders": [],          // Order submissions
  "users": [],           // Registered users
  "admin": {
    "username": "admin",
    "password": "admin123"
  }
}
```

## 🎯 Testing Flow:

### Test Admin:
1. Buka http://localhost:611/admin
2. Login dengan admin/admin123
3. Explore dashboard
4. Test CRUD portfolios
5. View contacts & orders

### Test User:
1. Buka http://localhost:611
2. Klik "Login" di navbar
3. Klik "Daftar di sini"
4. Register akun baru
5. Login ke dashboard
6. Submit order/message
7. View di "My Orders"

### Test Integration:
1. Submit order dari user dashboard
2. Login ke admin dashboard
3. Check order muncul di admin
4. Update status order
5. Logout admin, login user
6. Check status order updated

## 📁 Struktur File:

```
website-agency/
├── database.json              ← Database utama
├── server.js                  ← Backend server
├── package.json              ← Dependencies
├── .env                      ← Environment (PORT=611)
├── views/
│   ├── admin-login.html      ← Admin login
│   ├── admin.html            ← Admin dashboard
│   ├── user-register.html    ← User register
│   ├── user-login.html       ← User login
│   ├── user-dashboard.html   ← User dashboard
│   ├── index.ejs             ← Homepage
│   └── ...
├── public/
│   ├── js/
│   │   ├── admin.js          ← Admin logic
│   │   ├── user-dashboard.js ← User logic
│   │   └── ...
│   └── css/
│       └── style.css
├── README-ADMIN.md           ← Admin docs
├── README-USER-DASHBOARD.md  ← User docs
└── PERUBAHAN.md             ← Change log
```

## 🔥 Fitur Utama:

✅ Port 611
✅ Static JSON Database (no Firebase needed)
✅ Admin Dashboard (full CRUD)
✅ User Dashboard (register, login, order tracking)
✅ Session Management
✅ Responsive Design
✅ RESTful API

## 📚 Dokumentasi:

- **PERUBAHAN.md** - Ringkasan semua perubahan
- **README-ADMIN.md** - Dokumentasi admin lengkap
- **README-USER-DASHBOARD.md** - Dokumentasi user lengkap

## ⚠️ PENTING - Production:

1. **Ubah Admin Password:**
   Edit `database.json`:
   ```json
   "admin": {
     "username": "your-username",
     "password": "your-password"
   }
   ```

2. **Ubah Session Secret:**
   Edit `server.js`:
   ```javascript
   app.use(session({
     secret: 'your-secret-key',  // UBAH INI!
     ...
   }));
   ```

3. **Encrypt Passwords:**
   Install bcrypt untuk production:
   ```bash
   npm install bcrypt
   ```

4. **Enable HTTPS:**
   Set `cookie.secure: true` di session config

## 🐛 Troubleshooting:

**Port sudah digunakan:**
```bash
# Edit .env
PORT=8080
```

**Session tidak tersimpan:**
```bash
npm install express-session
```

**Database error:**
```bash
# Check permissions
chmod 644 database.json
```

## 🎉 Selesai!

Sistem lengkap dengan:
- ✅ Public website
- ✅ Admin dashboard
- ✅ User dashboard
- ✅ Order management
- ✅ Contact management
- ✅ Portfolio management

**Happy Coding! 🚀**
