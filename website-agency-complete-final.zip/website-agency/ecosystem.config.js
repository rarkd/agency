module.exports = {
  apps: [{
    name: 'website-agency',
    script: './server.js',
    instances: 2,
    exec_mode: 'cluster',
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',  // Increased from 500M
    env: {
      NODE_ENV: 'production',
      PORT: 611
    },
    env_development: {
      NODE_ENV: 'development',
      PORT: 611
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    merge_logs: true
  }]
};
