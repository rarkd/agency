#!/bin/bash

echo "🚀 AUTO UPDATE SCRIPT - Website Agency"
echo "========================================"
echo ""

# Backup original files
echo "📦 Creating backups..."
cp views/index.ejs views/index.ejs.backup
cp views/user-dashboard.html views/user-dashboard.html.backup
cp views/admin.html views/admin.html.backup
cp public/js/user-dashboard.js public/js/user-dashboard.js.backup
cp public/js/admin.js public/js/admin.js.backup

echo "✅ Backups created!"
echo ""
echo "📝 Applying updates..."
echo ""

# Update index.ejs - Change "Recent Projects" to "Portfolio"
echo "1. Updating homepage (Recent Projects → Portfolio)..."
sed -i 's/Recent Projects/Our Portfolio/g' views/index.ejs
sed -i 's/recent projects/portfolio/g' views/index.ejs

echo "2. Adding portfolio preview to admin..."
# This will be done via the additions files

echo "3. User Management & Chat features..."
# These are in the additions files

echo ""
echo "✅ Updates applied!"
echo ""
echo "📋 Next Steps:"
echo "   1. Check views/*-additions.html files"
echo "   2. Copy code to respective files"
echo "   3. Test each feature"
echo ""
echo "📖 Read IMPLEMENTATION-COMPLETE.md for details"

