# 🔧 FIX AUTO-RESTART & DEPLOYMENT

## ❓ Kenapa Ada 2 Instance?

**NORMAL & DISENGAJA!** Ini Cluster Mode untuk:

```javascript
instances: 2,           // 2 process untuk load balancing
exec_mode: 'cluster'   // Cluster mode
```

### Keuntungan Cluster Mode:
✅ Load balancing otomatis
✅ Zero-downtime reload
✅ Better CPU utilization
✅ High availability
✅ Jika 1 instance crash, yang lain masih jalan

### Cara Kerja:
```
Request → Port 611 → PM2 Load Balancer
                    ├─→ Instance 1 (process 12)
                    └─→ Instance 2 (process 13)
```

## 🐛 Fix Auto-Restart Issue

### Penyebab Auto-Restart:
1. **Memory limit terlalu kecil** (500MB)
2. Memory leak
3. Uncaught exceptions
4. Watch mode (sudah disabled)

### Solusi yang Sudah Diterapkan:

**1. Increase Memory Limit:**
```javascript
max_memory_restart: '1G'  // dari 500M → 1GB
```

**2. Disable Watch Mode:**
```javascript
watch: false  // sudah correct
```

**3. Error Handling:**
Check logs untuk error:
```bash
# Check error logs
pm2 logs website-agency --err

# Check all logs
pm2 logs website-agency

# Monitor in real-time
pm2 monit
```

## 📊 PM2 Commands

### Monitor Processes:
```bash
# List processes
pm2 list

# Monitor real-time
pm2 monit

# Show process details
pm2 show website-agency

# Check logs
pm2 logs website-agency
```

### Restart/Reload:
```bash
# Graceful reload (zero downtime)
pm2 reload website-agency

# Hard restart
pm2 restart website-agency

# Restart all
pm2 restart all

# Stop
pm2 stop website-agency

# Delete from PM2
pm2 delete website-agency
```

### Clean Start:
```bash
# Stop all
pm2 stop all

# Delete all
pm2 delete all

# Start fresh
pm2 start ecosystem.config.js
pm2 save
```

## 🔍 Debug Auto-Restart

### Check Memory Usage:
```bash
# Real-time monitoring
pm2 monit

# Memory info
pm2 show website-agency | grep memory
```

### Check Error Logs:
```bash
# View error logs
cat logs/err.log

# Watch logs real-time
tail -f logs/err.log
tail -f logs/out.log
```

### Common Issues:

**1. Memory Leak:**
```bash
# If restart karena memory
# Check di logs/out.log akan ada:
"Process xxxx exceeded memory limit"
```

**2. Uncaught Exception:**
```bash
# Check logs/err.log untuk:
"uncaughtException"
"unhandledRejection"
```

**3. Port Already in Use:**
```bash
# Check port
lsof -i :611

# Kill process
kill -9 <PID>
```

## ⚙️ Recommended PM2 Config

Jika masih restart, gunakan config ini:

```javascript
module.exports = {
  apps: [{
    name: 'website-agency',
    script: './server.js',
    instances: 1,              // Coba 1 instance dulu
    exec_mode: 'fork',         // Fork mode (bukan cluster)
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    min_uptime: '10s',         // Min uptime before restart
    max_restarts: 10,          // Max restart dalam 1 menit
    restart_delay: 4000,       // Delay 4s sebelum restart
    env: {
      NODE_ENV: 'production',
      PORT: 611
    }
  }]
};
```

## 🚀 Deploy Script Analysis

### deploy.sh creates:
1. PM2 ecosystem
2. 2 instances by default
3. Logs directory
4. Auto-start on reboot

### Normal behavior:
```bash
pm2 start ecosystem.config.js
# Creates 2 processes:
#  ├─ website-agency-0 (instance 1)
#  └─ website-agency-1 (instance 2)
```

## ✅ Recommended Actions

1. **Monitor for 1 hour:**
```bash
pm2 monit
# Watch memory usage
# Watch restart count
```

2. **If still restarting:**
```bash
# Check logs
pm2 logs website-agency --lines 100

# Try single instance
# Edit ecosystem.config.js:
instances: 1,
exec_mode: 'fork'

# Reload
pm2 reload ecosystem.config.js
```

3. **If stable, keep cluster mode:**
```bash
# Cluster mode = BEST for production
# Load balancing + High availability
```

## 📈 Performance Tips

### Optimize Memory:
```javascript
// Add to server.js
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection:', reason);
  process.exit(1);
});
```

### Monitor Health:
```bash
# Create health check
pm2 install pm2-server-monit

# Or use built-in monitoring
pm2 monit
```

## 🎯 Summary

- ✅ 2 instances = NORMAL (cluster mode)
- ✅ Memory limit increased to 1GB
- ✅ Watch mode disabled
- ⚠️ Monitor logs untuk error
- 💡 Use `pm2 monit` untuk real-time monitoring

**Jika masih restart setelah 1 jam, report error dari logs!**
