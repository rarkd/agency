# Website Agency - Jasa Pembuatan Website

Website profesional untuk jasa pembuatan website dengan teknologi Node.js, Firebase, PM2, dan Apache2.

## 🚀 Fitur Utama

- **Homepage** dengan hero section yang menarik
- **Portfolio** dengan 8+ contoh website
- **Pricing** dengan 3 paket (Bronze, Silver, Gold)
- **Contact Form** dengan integrasi Firebase
- **Responsive Design** untuk semua device
- **Modern UI/UX** dengan animasi smooth
- **SEO Optimized**

## 📦 Teknologi yang Digunakan

- **Backend**: Node.js + Express.js
- **Database**: Firebase Firestore
- **Process Manager**: PM2
- **Web Server**: Apache2 (Reverse Proxy)
- **Template Engine**: EJS
- **Styling**: Custom CSS dengan modern design

## 📋 Persyaratan Sistem

- Node.js v14 atau lebih tinggi
- NPM v6 atau lebih tinggi
- Apache2
- PM2 (global install)
- Firebase account

## 🛠️ Instalasi

### 1. Clone atau Download Project

```bash
cd /path/to/your/project
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Install PM2 (Global)

```bash
npm install -g pm2
```

### 4. Konfigurasi Environment Variables

Edit file `.env` dan sesuaikan dengan kebutuhan:

```env
PORT=3000
NODE_ENV=production
CONTACT_EMAIL=admin@webcraftstudio.com
```

### 5. Setup Firebase

1. Buat project baru di [Firebase Console](https://console.firebase.google.com/)
2. Enable Firestore Database
3. Generate Service Account Key:
   - Masuk ke Project Settings → Service Accounts
   - Click "Generate New Private Key"
   - Download file JSON
4. Rename file ke `firebase-service-account.json` dan letakkan di folder `config/`
5. Uncomment kode Firebase di `server.js`:

```javascript
const serviceAccount = require('./config/firebase-service-account.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://your-project-id.firebaseio.com"
});
const db = admin.firestore();
```

### 6. Setup Apache2

#### Install Apache2 dan Enable Modules

```bash
sudo apt update
sudo apt install apache2
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo a2enmod rewrite
sudo a2enmod headers
sudo a2enmod ssl
```

#### Copy Virtual Host Configuration

```bash
sudo cp config/apache2-vhost.conf /etc/apache2/sites-available/website-agency.conf
```

#### Edit Configuration

```bash
sudo nano /etc/apache2/sites-available/website-agency.conf
```

Ganti `yourwebsite.com` dengan domain Anda.

#### Enable Site dan Restart Apache

```bash
sudo a2ensite website-agency.conf
sudo systemctl restart apache2
```

### 7. Create Logs Directory

```bash
mkdir logs
```

## 🚀 Running the Application

### Development Mode

```bash
npm run dev
```

### Production Mode dengan PM2

#### Start Application

```bash
pm2 start ecosystem.config.js
```

#### Useful PM2 Commands

```bash
# Check status
pm2 status

# View logs
pm2 logs website-agency

# Restart application
pm2 restart website-agency

# Stop application
pm2 stop website-agency

# Delete from PM2
pm2 delete website-agency

# Save PM2 configuration
pm2 save

# Setup PM2 startup (auto-start on system boot)
pm2 startup
# Follow the command output
```

#### Monitor Application

```bash
pm2 monit
```

## 🔒 Setup SSL (Let's Encrypt)

### Install Certbot

```bash
sudo apt install certbot python3-certbot-apache
```

### Generate SSL Certificate

```bash
sudo certbot --apache -d yourwebsite.com -d www.yourwebsite.com
```

### Auto-renewal

Certbot akan otomatis setup cron job untuk renewal. Test dengan:

```bash
sudo certbot renew --dry-run
```

## 📁 Struktur Project

```
website-agency/
├── config/
│   ├── apache2-vhost.conf
│   └── firebase-service-account.template.json
├── public/
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── main.js
│       ├── portfolio.js
│       └── contact.js
├── views/
│   ├── index.ejs
│   ├── portfolio.ejs
│   ├── pricing.ejs
│   ├── contact.ejs
│   └── 404.ejs
├── logs/
├── .env
├── .gitignore
├── ecosystem.config.js
├── package.json
├── server.js
└── README.md
```

## 🎨 Customization

### Mengubah Warna

Edit variabel CSS di `public/css/style.css`:

```css
:root {
    --primary: #FF6B35;
    --secondary: #00D9FF;
    --accent: #FFD93D;
    /* ... */
}
```

### Menambah Portfolio Item

Edit array `portfolioWebsites` di `server.js`:

```javascript
const portfolioWebsites = [
  {
    id: 9,
    title: "Your New Project",
    category: "Category",
    description: "Description",
    image: "image-url",
    technologies: ["Tech1", "Tech2"],
    package: "gold"
  }
];
```

### Mengubah Paket Harga

Edit array `pricingPackages` di `server.js`.

## 🔧 Troubleshooting

### Port Already in Use

```bash
# Cari process yang menggunakan port 3000
sudo lsof -i :3000

# Kill process
sudo kill -9 <PID>
```

### Apache Error

```bash
# Check Apache error log
sudo tail -f /var/log/apache2/error.log

# Check Apache status
sudo systemctl status apache2

# Test Apache configuration
sudo apache2ctl configtest
```

### PM2 Not Starting

```bash
# Check PM2 logs
pm2 logs website-agency --lines 100

# Check for errors
pm2 describe website-agency
```

### Firebase Connection Error

- Pastikan file `firebase-service-account.json` sudah benar
- Cek project ID dan database URL
- Pastikan Firestore sudah enabled di Firebase Console

## 📊 Monitoring & Maintenance

### Check Application Status

```bash
pm2 status
pm2 monit
```

### View Logs

```bash
# PM2 logs
pm2 logs website-agency

# Apache logs
sudo tail -f /var/log/apache2/website-agency-access.log
sudo tail -f /var/log/apache2/website-agency-error.log
```

### Database Backup (Firebase)

Firebase Firestore memiliki automatic backup. Untuk export manual:
1. Firebase Console → Firestore Database
2. Pilih "Import/Export"
3. Export to Cloud Storage

## 🚀 Deployment Checklist

- [ ] Install dan configure Node.js
- [ ] Install dan configure Apache2
- [ ] Install PM2 globally
- [ ] Setup Firebase project
- [ ] Configure environment variables
- [ ] Setup virtual host Apache2
- [ ] Test application locally
- [ ] Setup SSL certificate
- [ ] Configure domain DNS
- [ ] Start with PM2
- [ ] Setup PM2 startup script
- [ ] Monitor logs
- [ ] Test all features

## 📞 Support

Jika ada pertanyaan atau masalah, hubungi:
- Email: admin@webcraftstudio.com
- Phone: +62 812-3456-7890

## 📝 License

Copyright © 2024 WebCraft Studio. All rights reserved.

## 🎯 Paket Harga

### Bronze Package - Rp 2.500.000
- Static Website (HTML, CSS, JS)
- Responsive Design
- Up to 5 Pages
- Basic SEO
- 2x Revisi

### Silver Package - Rp 8.500.000
- Dynamic Website (Node.js + MySQL)
- Admin Dashboard
- Up to 15 Pages
- Advanced SEO
- 3x Revisi

### Gold Package - Rp 15.000.000
- Dynamic Website (Node.js + MySQL)
- Advanced Admin Panel
- Unlimited Pages
- Payment Gateway Integration
- Cloud Hosting 1 Tahun
- Custom Domain
- SSL Certificate
- 5x Revisi
- 6 Bulan Support

## 🔄 Updates & Changelog

### Version 1.0.0 (2024)
- Initial release
- Portfolio with 8 examples
- 3 pricing packages
- Contact form with Firebase
- Responsive design
- PM2 & Apache2 configuration
