# 🔧 PANDUAN INTEGRASI FITUR BARU

## 📦 File-File yang Sudah Diupdate:

✅ **database.json** - Sudah ditambahkan `previewUrl` dan `chats` array
✅ **server.js** - Sudah ditambahkan semua API endpoints
✅ **portfolio.ejs** - Sudah ditambahkan preview button
✅ **style.css** - Sudah ditambahkan CSS untuk preview button

## 📝 File-File yang Perlu Diupdate Manual:

### 1. views/user-dashboard.html

Buka file `user-dashboard-additions.html` dan ikuti instruksi:

**Langkah 1: Tambah Chat Tab**
Cari section tabs (sekitar line 100-110):
```html
<div class="tabs">
    <button class="tab active" onclick="switchTab('orders')">My Orders</button>
    <button class="tab" onclick="switchTab('contacts')">My Messages</button>
    <button class="tab" onclick="switchTab('newOrder')">New Order</button>
    <!-- TAMBAHKAN DISINI: -->
    <button class="tab" onclick="switchTab('chat')">💬 Chat</button>
</div>
```

**Langkah 2: Update Order Form**
Cari form orderForm (sekitar line 180), tambahkan SEBELUM field Package:
```html
<div class="form-group">
    <label>Template Reference (Optional)</label>
    <select id="orderTemplate">
        <option value="">-- Pilih Template (opsional) --</option>
    </select>
    <small style="color: #666; font-size: 12px;">Pilih template sebagai referensi</small>
</div>
```

**Langkah 3: Update Orders Table Header**
Cari orders table header (sekitar line 120), ubah:
```html
<thead>
    <tr>
        <th>Date</th>
        <th>Package</th>
        <th>Template</th>  <!-- TAMBAHKAN INI -->
        <th>Requirements</th>
        <th>Status</th>
    </tr>
</thead>
```

**Langkah 4: Tambah Chat Tab Content**
Copy semua content dari `user-dashboard-additions.html` bagian "CHAT TAB" dan paste setelah `newOrderTab` div (sebelum closing `</div>` container).

**Langkah 5: Tambah CSS**
Copy semua CSS dari `user-dashboard-additions.html` dan paste di section `<style>` atau di file CSS.

### 2. public/js/user-dashboard.js

Buka file `user-dashboard-additions.js` dan ikuti:

**Langkah 1: Update DOMContentLoaded**
Tambahkan 2 baris ini:
```javascript
loadTemplates();  // NEW
loadChats();      // NEW
// Dan tambahkan:
setInterval(loadChats, 5000);
```

**Langkah 2: Tambah Functions Baru**
Copy semua functions dari `user-dashboard-additions.js`:
- `loadTemplates()`
- `loadChats()`
- `sendMessage()`

**Langkah 3: Replace setupOrderForm()**
Ganti function `setupOrderForm()` dengan versi baru yang include `templateId`

**Langkah 4: Update loadOrders()**
Ganti function `loadOrders()` dengan versi baru yang tampilkan template column

### 3. views/admin.html

Buka file `admin-dashboard-additions.html` dan ikuti:

**Langkah 1: Tambah Tabs**
Cari section tabs (sekitar line 100-110):
```html
<div class="tabs">
    <button class="tab active" onclick="switchTab('contacts')">Contacts</button>
    <button class="tab" onclick="switchTab('orders')">Orders</button>
    <button class="tab" onclick="switchTab('portfolios')">Portfolios</button>
    <!-- TAMBAHKAN DISINI: -->
    <button class="tab" onclick="switchTab('users')">Users</button>
    <button class="tab" onclick="switchTab('adminChat')">💬 Chat</button>
</div>
```

**Langkah 2: Update Orders Table Header**
Cari orders table (sekitar line 180):
```html
<thead>
    <tr>
        <th>Date</th>
        <th>Name</th>
        <th>Phone</th>      <!-- TAMBAHKAN -->
        <th>Package</th>
        <th>Template</th>   <!-- TAMBAHKAN -->
        <th>Status</th>
        <th>Actions</th>
    </tr>
</thead>
```

**Langkah 3: Tambah Users Tab**
Copy semua content "USERS TAB" dari `admin-dashboard-additions.html` dan paste setelah `portfoliosTab`.

**Langkah 4: Tambah Admin Chat Tab**
Copy semua content "ADMIN CHAT TAB" dari `admin-dashboard-additions.html` dan paste setelah `usersTab`.

**Langkah 5: Tambah CSS**
Copy semua CSS dari `admin-dashboard-additions.html` dan paste di section `<style>`.

### 4. public/js/admin.js

Buka file `admin-dashboard-additions.js` dan ikuti:

**Langkah 1: Tambah Global Variable**
Di bagian paling atas:
```javascript
let currentChatUserId = null;
```

**Langkah 2: Update DOMContentLoaded**
Tambahkan:
```javascript
loadUsers();        // NEW
loadAdminChats();   // NEW
// Dan tambahkan:
setInterval(() => {
    if (currentChatUserId) {
        loadAdminChats();
    }
}, 5000);
```

**Langkah 3: Tambah Functions Baru**
Copy semua functions dari `admin-dashboard-additions.js`:
- `loadUsers()`
- `deleteUser(id)`
- `loadAdminChats()`
- `openUserChat(userId)`
- `displayChatMessages(userChat)`
- `sendAdminMessage()`

**Langkah 4: Replace loadOrders() dan viewOrder()**
Ganti dengan versi baru yang include phone dan template columns.

## ✅ Checklist Integrasi

- [ ] Database.json sudah updated (✓ DONE)
- [ ] Server.js sudah updated (✓ DONE)
- [ ] Portfolio.ejs sudah updated (✓ DONE)
- [ ] Style.css sudah updated (✓ DONE)
- [ ] User dashboard HTML - tambah chat tab
- [ ] User dashboard HTML - tambah template select
- [ ] User dashboard HTML - update table header
- [ ] User dashboard HTML - tambah CSS
- [ ] User dashboard JS - tambah functions
- [ ] Admin dashboard HTML - tambah users tab
- [ ] Admin dashboard HTML - tambah chat tab
- [ ] Admin dashboard HTML - update table header
- [ ] Admin dashboard HTML - tambah CSS
- [ ] Admin dashboard JS - tambah functions

## 🚀 Testing

Setelah semua diintegrasikan:

1. **Test Portfolio Preview:**
   ```
   - Buka /portfolio
   - Klik "Preview Demo" pada portfolio
   - Harus buka link di tab baru
   ```

2. **Test User Dashboard:**
   ```
   - Register/Login user
   - Buka New Order tab
   - Lihat template dropdown terisi
   - Submit order dengan template
   - Cek di My Orders ada template badge
   - Buka Chat tab
   - Kirim message ke admin
   ```

3. **Test Admin Dashboard:**
   ```
   - Login admin
   - Buka Users tab - lihat registered users
   - Buka Chat tab - lihat user messages
   - Reply ke user message
   - Buka Orders tab - lihat phone dan template
   - View order detail - lihat semua info lengkap
   ```

## 📞 API Reference Cepat

```javascript
// Chat
GET /api/chats                          // User: get chats
POST /api/chats                         // User: send message
GET /api/admin/chats                    // Admin: get all chats
POST /api/admin/chats                   // Admin: send reply
PUT /api/admin/chats/:userId/read       // Admin: mark read

// Users
GET /api/admin/users                    // Get all users
DELETE /api/admin/users/:id             // Delete user

// Orders (updated)
POST /api/user/order                    // Submit with templateId
```

## 🎨 Preview Fitur

### Portfolio Preview Button:
![Preview] Button membuka demo template di tab baru

### Chat Interface:
```
User Dashboard:
┌─────────────────────────────┐
│ 💬 Chat with Admin          │
├─────────────────────────────┤
│ User: Hi, I need help       │
│ Admin: Hello! How can I...  │
│ User: About pricing...      │
├─────────────────────────────┤
│ [Type message...] [Send]    │
└─────────────────────────────┘

Admin Dashboard:
┌──────────┬─────────────────┐
│ John Doe │ User: Hi...     │
│ Jane S.  │ Admin: Sure...  │
│ Mike T.  │ User: Thanks    │
└──────────┴─────────────────┘
```

### Order dengan Template:
```
Order Details:
- Name: John Doe
- Phone: 08123456789  ← NEW!
- Package: Gold
- Template: E-Commerce Fashion Store  ← NEW!
  [👁️ View Template Preview]
- Requirements: ...
```

## 💡 Tips

1. **Backup dulu** file asli sebelum edit
2. **Edit satu fitur** at a time, test dulu sebelum lanjut
3. **Check console** browser (F12) untuk error
4. **Restart server** setelah edit server.js
5. **Clear cache** browser jika CSS tidak update

## 🐛 Troubleshooting

**Template dropdown kosong?**
- Check apakah `loadTemplates()` dipanggil
- Check console untuk error
- Verify `/api/portfolios` returns data

**Chat tidak muncul?**
- Check `database.json` ada array `chats`
- Check API endpoints di server.js
- Check browser console untuk error

**Users tab kosong?**
- Register user dulu via `/user/register`
- Check `/api/admin/users` di browser

## 📞 Support

Jika ada masalah:
1. Check file `FITUR-BARU.md` untuk referensi lengkap
2. Check browser console (F12)
3. Check server logs di terminal
4. Verify semua file additions sudah diintegrasikan

**Semua fitur sudah siap! Tinggal integrasi manual ke HTML dan JS files.**
