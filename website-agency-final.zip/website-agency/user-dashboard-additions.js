// ============================================
// TAMBAHAN UNTUK user-dashboard.js
// ============================================

// ADD TO DOMContentLoaded:
document.addEventListener('DOMContentLoaded', () => {
    loadProfile();
    loadStats();
    loadOrders();
    loadContacts();
    loadTemplates();  // NEW: Load templates for order form
    loadChats();      // NEW: Load chat messages
    
    setupOrderForm();
    setupContactForm();
    
    // NEW: Auto-refresh chat every 5 seconds
    setInterval(loadChats, 5000);
});

// NEW FUNCTION: Load templates into select dropdown
async function loadTemplates() {
    try {
        const response = await fetch('/api/portfolios');
        const portfolios = await response.json();
        
        const select = document.getElementById('orderTemplate');
        if (!select) return;
        
        portfolios.forEach(portfolio => {
            const option = document.createElement('option');
            option.value = portfolio.id;
            option.textContent = `${portfolio.title} (${portfolio.package.toUpperCase()})`;
            select.appendChild(option);
        });
    } catch (error) {
        console.error('Error loading templates:', error);
    }
}

// NEW FUNCTION: Load chat messages
async function loadChats() {
    try {
        const response = await fetch('/api/chats');
        const chats = await response.json();
        
        const chatMessages = document.getElementById('chatMessages');
        const loading = document.getElementById('chatLoading');
        
        if (loading) loading.style.display = 'none';
        
        if (chats.length === 0) {
            chatMessages.innerHTML = '<div class="empty-state">No messages yet. Start a conversation!</div>';
            return;
        }
        
        chatMessages.innerHTML = chats.map(chat => `
            <div class="chat-message ${chat.sender}">
                <div class="chat-sender">${chat.sender === 'user' ? 'You' : 'Admin'}</div>
                <div>${chat.message}</div>
                <div class="chat-time">${new Date(chat.timestamp).toLocaleString('id-ID', {
                    hour: '2-digit',
                    minute: '2-digit',
                    month: 'short',
                    day: 'numeric'
                })}</div>
            </div>
        `).join('');
        
        // Scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    } catch (error) {
        console.error('Error loading chats:', error);
    }
}

// NEW FUNCTION: Send chat message
async function sendMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    try {
        const response = await fetch('/api/chats', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message })
        });
        
        const data = await response.json();
        
        if (data.success) {
            input.value = '';
            loadChats();
        }
    } catch (error) {
        console.error('Error sending message:', error);
        alert('Failed to send message. Please try again.');
    }
}

// UPDATE FUNCTION: Modified setupOrderForm to include templateId
function setupOrderForm() {
    document.getElementById('orderForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const packageType = document.getElementById('orderPackage').value;
        const requirements = document.getElementById('orderRequirements').value;
        const templateId = document.getElementById('orderTemplate') ? 
                          document.getElementById('orderTemplate').value : null;
        
        const successMsg = document.getElementById('orderSuccessMessage');
        const errorMsg = document.getElementById('orderErrorMessage');
        
        successMsg.style.display = 'none';
        errorMsg.style.display = 'none';
        
        try {
            const response = await fetch('/api/user/order', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    package: packageType,
                    requirements: requirements,
                    templateId: templateId || null
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                successMsg.textContent = data.message;
                successMsg.style.display = 'block';
                
                // Reset form
                document.getElementById('orderForm').reset();
                
                // Reload data
                loadStats();
                loadOrders();
                
                // Switch to orders tab after 2 seconds
                setTimeout(() => {
                    document.querySelector('.tab').click();
                }, 2000);
            } else {
                errorMsg.textContent = data.message || 'Terjadi kesalahan';
                errorMsg.style.display = 'block';
            }
        } catch (error) {
            console.error('Error submitting order:', error);
            errorMsg.textContent = 'Terjadi kesalahan. Silakan coba lagi.';
            errorMsg.style.display = 'block';
        }
    });
}

// UPDATE FUNCTION: Enhanced loadOrders to show template info
async function loadOrders() {
    try {
        const response = await fetch('/api/user/orders');
        const orders = await response.json();
        
        const tbody = document.getElementById('ordersTableBody');
        
        if (orders.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="empty-state">Belum ada order</td></tr>';
            return;
        }
        
        tbody.innerHTML = orders.map(order => `
            <tr>
                <td>${new Date(order.timestamp).toLocaleDateString('id-ID')}</td>
                <td><strong>${order.package}</strong></td>
                <td>${order.template ? 
                    `<span style="color: #667eea;">📋 ${order.template.title}</span>` : 
                    '-'}</td>
                <td style="max-width: 300px; overflow: hidden; text-overflow: ellipsis;">${order.requirements}</td>
                <td><span class="status-badge status-${order.status}">${order.status}</span></td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading orders:', error);
    }
}

// NOTE: Jangan lupa update HTML table header untuk orders:
// <th>Date</th>
// <th>Package</th>
// <th>Template</th>  <!-- NEW COLUMN -->
// <th>Requirements</th>
// <th>Status</th>
