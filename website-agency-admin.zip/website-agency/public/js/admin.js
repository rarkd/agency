// Global variables
let currentContactId = null;
let currentOrderId = null;
let technologies = [];

// Load initial data
document.addEventListener('DOMContentLoaded', () => {
    loadStats();
    loadContacts();
    loadOrders();
    loadPortfolios();
    
    setupTechInput();
});

// Tab switching
function switchTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    event.target.classList.add('active');
    
    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    document.getElementById(tabName + 'Tab').classList.add('active');
}

// Load statistics
async function loadStats() {
    try {
        const response = await fetch('/api/admin/stats');
        const stats = await response.json();
        
        document.getElementById('statContacts').textContent = stats.totalContacts;
        document.getElementById('statOrders').textContent = stats.totalOrders;
        document.getElementById('statPortfolios').textContent = stats.totalPortfolios;
        document.getElementById('statPending').textContent = stats.pendingOrders;
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Load contacts
async function loadContacts() {
    try {
        const response = await fetch('/api/admin/contacts');
        const contacts = await response.json();
        
        const tbody = document.getElementById('contactsTableBody');
        
        if (contacts.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="empty-state">No contacts yet</td></tr>';
            return;
        }
        
        tbody.innerHTML = contacts.map(contact => `
            <tr>
                <td>${new Date(contact.timestamp).toLocaleDateString('id-ID')}</td>
                <td>${contact.name}</td>
                <td>${contact.email}</td>
                <td>${contact.phone}</td>
                <td>${contact.package}</td>
                <td><span class="status-badge status-${contact.status}">${contact.status}</span></td>
                <td>
                    <div class="action-btns">
                        <button class="action-btn btn-edit" onclick="viewContact(${contact.id})">View</button>
                    </div>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading contacts:', error);
    }
}

// Load orders
async function loadOrders() {
    try {
        const response = await fetch('/api/admin/orders');
        const orders = await response.json();
        
        const tbody = document.getElementById('ordersTableBody');
        
        if (orders.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="empty-state">No orders yet</td></tr>';
            return;
        }
        
        tbody.innerHTML = orders.map(order => `
            <tr>
                <td>${new Date(order.timestamp).toLocaleDateString('id-ID')}</td>
                <td>${order.name}</td>
                <td>${order.email}</td>
                <td>${order.package}</td>
                <td><span class="status-badge status-${order.status}">${order.status}</span></td>
                <td>
                    <div class="action-btns">
                        <button class="action-btn btn-edit" onclick="viewOrder(${order.id})">View</button>
                    </div>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading orders:', error);
    }
}

// Load portfolios
async function loadPortfolios() {
    try {
        const response = await fetch('/api/portfolios');
        const portfolios = await response.json();
        
        const tbody = document.getElementById('portfoliosTableBody');
        
        if (portfolios.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="empty-state">No portfolios yet</td></tr>';
            return;
        }
        
        tbody.innerHTML = portfolios.map(portfolio => `
            <tr>
                <td>${portfolio.title}</td>
                <td>${portfolio.category}</td>
                <td>${portfolio.package}</td>
                <td>${portfolio.technologies.join(', ')}</td>
                <td>
                    <div class="action-btns">
                        <button class="action-btn btn-edit" onclick="editPortfolio(${portfolio.id})">Edit</button>
                        <button class="action-btn btn-delete" onclick="deletePortfolio(${portfolio.id})">Delete</button>
                    </div>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading portfolios:', error);
    }
}

// View contact details
async function viewContact(id) {
    try {
        const response = await fetch('/api/admin/contacts');
        const contacts = await response.json();
        const contact = contacts.find(c => c.id === id);
        
        currentContactId = id;
        
        document.getElementById('contactDetails').innerHTML = `
            <div class="form-group">
                <label>Name:</label>
                <p>${contact.name}</p>
            </div>
            <div class="form-group">
                <label>Email:</label>
                <p>${contact.email}</p>
            </div>
            <div class="form-group">
                <label>Phone:</label>
                <p>${contact.phone}</p>
            </div>
            <div class="form-group">
                <label>Package:</label>
                <p>${contact.package}</p>
            </div>
            <div class="form-group">
                <label>Message:</label>
                <p>${contact.message}</p>
            </div>
            <div class="form-group">
                <label>Date:</label>
                <p>${new Date(contact.timestamp).toLocaleString('id-ID')}</p>
            </div>
        `;
        
        openModal('contactModal');
    } catch (error) {
        console.error('Error viewing contact:', error);
    }
}

// Delete contact
async function deleteContact() {
    if (!confirm('Are you sure you want to delete this contact?')) return;
    
    try {
        const response = await fetch(`/api/admin/contacts/${currentContactId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            closeModal('contactModal');
            loadContacts();
            loadStats();
            alert('Contact deleted successfully!');
        }
    } catch (error) {
        console.error('Error deleting contact:', error);
        alert('Error deleting contact');
    }
}

// View order details
async function viewOrder(id) {
    try {
        const response = await fetch('/api/admin/orders');
        const orders = await response.json();
        const order = orders.find(o => o.id === id);
        
        currentOrderId = id;
        
        document.getElementById('orderDetails').innerHTML = `
            <div class="form-group">
                <label>Name:</label>
                <p>${order.name}</p>
            </div>
            <div class="form-group">
                <label>Email:</label>
                <p>${order.email}</p>
            </div>
            <div class="form-group">
                <label>Phone:</label>
                <p>${order.phone}</p>
            </div>
            <div class="form-group">
                <label>Package:</label>
                <p>${order.package}</p>
            </div>
            <div class="form-group">
                <label>Requirements:</label>
                <p>${order.requirements}</p>
            </div>
            <div class="form-group">
                <label>Date:</label>
                <p>${new Date(order.timestamp).toLocaleString('id-ID')}</p>
            </div>
        `;
        
        document.getElementById('orderStatus').value = order.status;
        
        openModal('orderModal');
    } catch (error) {
        console.error('Error viewing order:', error);
    }
}

// Update order status
async function updateOrderStatus() {
    const status = document.getElementById('orderStatus').value;
    
    try {
        const response = await fetch(`/api/admin/orders/${currentOrderId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ status })
        });
        
        const data = await response.json();
        
        if (data.success) {
            closeModal('orderModal');
            loadOrders();
            loadStats();
            alert('Order status updated!');
        }
    } catch (error) {
        console.error('Error updating order:', error);
        alert('Error updating order');
    }
}

// Delete order
async function deleteOrder() {
    if (!confirm('Are you sure you want to delete this order?')) return;
    
    try {
        const response = await fetch(`/api/admin/orders/${currentOrderId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            closeModal('orderModal');
            loadOrders();
            loadStats();
            alert('Order deleted successfully!');
        }
    } catch (error) {
        console.error('Error deleting order:', error);
        alert('Error deleting order');
    }
}

// Portfolio management
function openPortfolioModal(portfolioData = null) {
    if (portfolioData) {
        document.getElementById('portfolioModalTitle').textContent = 'Edit Portfolio';
        document.getElementById('portfolioId').value = portfolioData.id;
        document.getElementById('portfolioTitle').value = portfolioData.title;
        document.getElementById('portfolioCategory').value = portfolioData.category;
        document.getElementById('portfolioDescription').value = portfolioData.description;
        document.getElementById('portfolioImage').value = portfolioData.image;
        document.getElementById('portfolioPackage').value = portfolioData.package;
        technologies = [...portfolioData.technologies];
        renderTechnologies();
    } else {
        document.getElementById('portfolioModalTitle').textContent = 'Add Portfolio';
        document.getElementById('portfolioForm').reset();
        document.getElementById('portfolioId').value = '';
        technologies = [];
        renderTechnologies();
    }
    
    openModal('portfolioModal');
}

async function editPortfolio(id) {
    try {
        const response = await fetch('/api/portfolios');
        const portfolios = await response.json();
        const portfolio = portfolios.find(p => p.id === id);
        
        openPortfolioModal(portfolio);
    } catch (error) {
        console.error('Error loading portfolio:', error);
    }
}

async function deletePortfolio(id) {
    if (!confirm('Are you sure you want to delete this portfolio?')) return;
    
    try {
        const response = await fetch(`/api/admin/portfolios/${id}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            loadPortfolios();
            loadStats();
            alert('Portfolio deleted successfully!');
        }
    } catch (error) {
        console.error('Error deleting portfolio:', error);
        alert('Error deleting portfolio');
    }
}

// Handle portfolio form submission
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('portfolioForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const portfolioData = {
            title: document.getElementById('portfolioTitle').value,
            category: document.getElementById('portfolioCategory').value,
            description: document.getElementById('portfolioDescription').value,
            image: document.getElementById('portfolioImage').value,
            technologies: technologies,
            package: document.getElementById('portfolioPackage').value
        };
        
        const id = document.getElementById('portfolioId').value;
        const isEdit = id !== '';
        
        try {
            const response = await fetch(
                isEdit ? `/api/admin/portfolios/${id}` : '/api/admin/portfolios',
                {
                    method: isEdit ? 'PUT' : 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(portfolioData)
                }
            );
            
            const data = await response.json();
            
            if (data.success) {
                closeModal('portfolioModal');
                loadPortfolios();
                loadStats();
                alert(isEdit ? 'Portfolio updated!' : 'Portfolio added!');
            }
        } catch (error) {
            console.error('Error saving portfolio:', error);
            alert('Error saving portfolio');
        }
    });
});

// Technologies input handler
function setupTechInput() {
    const input = document.getElementById('techInput');
    
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            const value = input.value.trim();
            if (value && !technologies.includes(value)) {
                technologies.push(value);
                renderTechnologies();
                input.value = '';
            }
        }
    });
}

function renderTechnologies() {
    const container = document.getElementById('techContainer');
    const input = document.getElementById('techInput');
    
    // Clear existing tags except input
    const existingTags = container.querySelectorAll('.tech-tag');
    existingTags.forEach(tag => tag.remove());
    
    // Add technology tags
    technologies.forEach((tech, index) => {
        const tag = document.createElement('span');
        tag.className = 'tech-tag';
        tag.innerHTML = `
            ${tech}
            <button type="button" onclick="removeTechnology(${index})">×</button>
        `;
        container.insertBefore(tag, input);
    });
}

function removeTechnology(index) {
    technologies.splice(index, 1);
    renderTechnologies();
}

// Modal functions
function openModal(modalId) {
    document.getElementById(modalId).classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

// Logout
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        window.location.href = '/admin/logout';
    }
}
