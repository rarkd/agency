#!/bin/bash

# Apache2 Setup Script
echo "🔧 Setting up Apache2..."

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}❌ Please run as root (use sudo)${NC}"
    exit 1
fi

# Check if Apache2 is installed
if ! command -v apache2 &> /dev/null; then
    echo -e "${YELLOW}📦 Installing Apache2...${NC}"
    apt update
    apt install -y apache2
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Failed to install Apache2${NC}"
        exit 1
    fi
fi

echo -e "${GREEN}✓ Apache2 is installed${NC}"

# Enable required modules
echo -e "${YELLOW}🔧 Enabling required Apache modules...${NC}"
a2enmod proxy
a2enmod proxy_http
a2enmod rewrite
a2enmod headers
a2enmod ssl

echo -e "${GREEN}✓ Modules enabled${NC}"

# Copy virtual host configuration
echo -e "${YELLOW}📄 Copying virtual host configuration...${NC}"

# Get current directory
CURRENT_DIR=$(pwd)

# Copy configuration
cp "$CURRENT_DIR/config/apache2-vhost.conf" /etc/apache2/sites-available/website-agency.conf

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Failed to copy configuration${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Configuration copied${NC}"

# Prompt for domain
echo -e "${YELLOW}Please enter your domain name (e.g., example.com):${NC}"
read DOMAIN

if [ -z "$DOMAIN" ]; then
    echo -e "${RED}❌ Domain name cannot be empty${NC}"
    exit 1
fi

# Replace domain in configuration
sed -i "s/yourwebsite.com/$DOMAIN/g" /etc/apache2/sites-available/website-agency.conf

echo -e "${GREEN}✓ Domain configured: $DOMAIN${NC}"

# Disable default site
a2dissite 000-default.conf

# Enable website
echo -e "${YELLOW}🔧 Enabling website...${NC}"
a2ensite website-agency.conf

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Failed to enable site${NC}"
    exit 1
fi

# Test Apache configuration
echo -e "${YELLOW}🧪 Testing Apache configuration...${NC}"
apache2ctl configtest

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Apache configuration test failed${NC}"
    echo -e "${YELLOW}Please check the configuration and try again${NC}"
    exit 1
fi

# Restart Apache
echo -e "${YELLOW}🔄 Restarting Apache2...${NC}"
systemctl restart apache2

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Failed to restart Apache2${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Apache2 restarted${NC}"

# Check Apache status
systemctl status apache2 --no-pager

echo ""
echo -e "${GREEN}✅ Apache2 setup completed successfully!${NC}"
echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo "1. Make sure your Node.js application is running on port 3000"
echo "2. Configure your domain DNS to point to this server"
echo "3. (Optional) Install SSL certificate:"
echo "   sudo apt install certbot python3-certbot-apache"
echo "   sudo certbot --apache -d $DOMAIN -d www.$DOMAIN"
echo ""
echo -e "${YELLOW}Your website will be accessible at: http://$DOMAIN${NC}"
