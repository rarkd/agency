# Quick Start Guide - Website Agency

## 🚀 Cara Cepat Memulai

### 1. Install Dependencies

```bash
npm install
```

### 2. Setup Environment

```bash
# Edit .env file
nano .env
```

### 3. Jalankan Development Server

```bash
npm run dev
```

Buka browser: http://localhost:3000

---

## 📦 Production Deployment

### Automatic Deployment

```bash
chmod +x deploy.sh
./deploy.sh
```

### Manual Deployment

```bash
# Install dependencies
npm install

# Install PM2 globally
sudo npm install -g pm2

# Create logs directory
mkdir logs

# Start with PM2
pm2 start ecosystem.config.js

# Save PM2 config
pm2 save

# Setup auto-start on boot
pm2 startup
```

---

## 🔧 Setup Apache2 (Production)

### Automatic Setup

```bash
chmod +x setup-apache.sh
sudo ./setup-apache.sh
```

### Manual Setup

```bash
# Install Apache2
sudo apt install apache2

# Enable modules
sudo a2enmod proxy proxy_http rewrite headers ssl

# Copy virtual host
sudo cp config/apache2-vhost.conf /etc/apache2/sites-available/website-agency.conf

# Edit domain
sudo nano /etc/apache2/sites-available/website-agency.conf

# Enable site
sudo a2ensite website-agency.conf

# Restart Apache
sudo systemctl restart apache2
```

---

## 🔥 Setup Firebase

1. Buat project di https://console.firebase.google.com
2. Enable Firestore Database
3. Generate Service Account Key
4. Download dan rename ke `firebase-service-account.json`
5. Letakkan di folder `config/`
6. Uncomment kode Firebase di `server.js`

---

## 🔒 Setup SSL Certificate (Let's Encrypt)

```bash
# Install Certbot
sudo apt install certbot python3-certbot-apache

# Generate certificate
sudo certbot --apache -d yourdomain.com -d www.yourdomain.com

# Test auto-renewal
sudo certbot renew --dry-run
```

---

## 📊 Monitoring Commands

```bash
# Check PM2 status
pm2 status

# View logs
pm2 logs website-agency

# Monitor in real-time
pm2 monit

# Restart application
pm2 restart website-agency

# Stop application
pm2 stop website-agency
```

---

## 🐛 Troubleshooting

### Port 3000 already in use

```bash
# Find process
sudo lsof -i :3000

# Kill process
sudo kill -9 <PID>
```

### Apache error

```bash
# Check logs
sudo tail -f /var/log/apache2/error.log

# Test config
sudo apache2ctl configtest

# Restart
sudo systemctl restart apache2
```

### PM2 not starting

```bash
# Check logs
pm2 logs website-agency --lines 50

# Restart
pm2 restart website-agency

# Delete and restart
pm2 delete website-agency
pm2 start ecosystem.config.js
```

---

## 📞 Need Help?

- Email: admin@webcraftstudio.com
- Phone: +62 812-3456-7890

---

## ✅ Checklist Deployment

- [ ] Node.js installed
- [ ] npm install completed
- [ ] .env configured
- [ ] Firebase setup done
- [ ] PM2 running
- [ ] Apache2 configured
- [ ] Domain DNS configured
- [ ] SSL certificate installed
- [ ] Test all pages
- [ ] Test contact form
- [ ] Monitor logs

**Selamat! Website Anda sudah siap! 🎉**
