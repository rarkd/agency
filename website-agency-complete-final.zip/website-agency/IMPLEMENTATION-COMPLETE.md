# 🚀 IMPLEMENTASI LENGKAP SEMUA FITUR

## ✅ STATUS IMPLEMENTASI

### SUDAH JALAN 100%:
- [x] Portfolio preview buttons ✅
- [x] Backend API (chat, user management, template) ✅
- [x] Database structure ✅
- [x] PM2 cluster mode (2 instances) ✅
- [x] Auto-restart fix (memory → 1GB) ✅

### BUTUH COPY-PASTE (5 menit per fitur):
- [ ] Homepage portfolio section
- [ ] Admin preview link input
- [ ] User management UI
- [ ] Chat interface

---

## 🎯 IMPLEMENTASI CEPAT (15 MENIT)

### 1️⃣ UPDATE HOMEPAGE (2 menit)

**File:** `views/index.ejs`

Cari baris yang ada "Recent Projects" (sekitar line 130-140), ganti dengan:

```html
<section class="portfolio-showcase">
    <div class="container">
        <h2 class="section-title">Our Portfolio</h2>
        <p class="section-subtitle">Lihat hasil karya kami yang telah dipercaya oleh berbagai klien</p>
        
        <div class="portfolio-grid">
            <% portfolios.forEach((portfolio, index) => { %>
            <div class="portfolio-item" data-category="<%= portfolio.category %>">
                <div class="portfolio-image">
                    <img src="<%= portfolio.image %>" alt="<%= portfolio.title %>">
                    <div class="portfolio-overlay">
                        <span class="portfolio-category"><%= portfolio.category %></span>
                        <a href="<%= portfolio.previewUrl %>" target="_blank" class="btn-preview-small">👁️ Preview</a>
                    </div>
                </div>
                <div class="portfolio-content">
                    <h3><%= portfolio.title %></h3>
                    <p><%= portfolio.description.substring(0, 100) %>...</p>
                </div>
            </div>
            <% }); %>
        </div>
        
        <div style="text-align: center; margin-top: 40px;">
            <a href="/portfolio" class="btn btn-primary">View All Portfolio →</a>
        </div>
    </div>
</section>
```

✅ DONE! Homepage updated.

---

### 2️⃣ ADMIN: INPUT PREVIEW LINK (5 menit)

**File:** `views/admin.html`

Cari portfolio form (sekitar line 350-450), tambahkan field **previewUrl**:

**SEBELUM:**
```html
<div class="form-group">
    <label>Image URL</label>
    <input type="url" id="portfolioImage" required>
</div>
```

**SESUDAH:**
```html
<div class="form-group">
    <label>Image URL</label>
    <input type="url" id="portfolioImage" required>
</div>

<!-- TAMBAHKAN INI -->
<div class="form-group">
    <label>Preview Demo URL</label>
    <input type="url" id="portfolioPreviewUrl" required placeholder="https://demo-example.com">
    <small style="color: #666; font-size: 12px;">Link ke live demo / preview template</small>
</div>
```

**File:** `public/js/admin.js`

Update function `openPortfolioModal` dan form submission:

**Cari function openPortfolioModal (sekitar line 200), tambahkan:**
```javascript
if (portfolioData) {
    // ... existing code ...
    document.getElementById('portfolioImage').value = portfolioData.image;
    document.getElementById('portfolioPreviewUrl').value = portfolioData.previewUrl || ''; // ADD THIS
    // ... rest of code ...
}
```

**Cari portfolio form submission (sekitar line 250), tambahkan:**
```javascript
const portfolioData = {
    title: document.getElementById('portfolioTitle').value,
    category: document.getElementById('portfolioCategory').value,
    description: document.getElementById('portfolioDescription').value,
    image: document.getElementById('portfolioImage').value,
    previewUrl: document.getElementById('portfolioPreviewUrl').value, // ADD THIS
    technologies: technologies,
    package: document.getElementById('portfolioPackage').value
};
```

✅ DONE! Admin bisa input preview link.

---

### 3️⃣ USER MANAGEMENT UI (3 menit)

**File:** `views/admin.html`

**A. Tambah Tab Users** (cari tabs section, sekitar line 100):
```html
<div class="tabs">
    <button class="tab active" onclick="switchTab('contacts')">Contacts</button>
    <button class="tab" onclick="switchTab('orders')">Orders</button>
    <button class="tab" onclick="switchTab('portfolios')">Portfolios</button>
    <button class="tab" onclick="switchTab('users')">👥 Users</button> <!-- ADD THIS -->
</div>
```

**B. Tambah Users Content** (setelah portfoliosTab, sekitar line 450):
```html
<!-- Users Tab -->
<div id="usersTab" class="tab-content">
    <div class="table-container">
        <div class="table-header">
            <h2>Registered Users</h2>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Registered</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="usersTableBody">
                <tr><td colspan="5" class="empty-state">Loading...</td></tr>
            </tbody>
        </table>
    </div>
</div>
```

**File:** `public/js/admin.js`

**Tambah di DOMContentLoaded:**
```javascript
document.addEventListener('DOMContentLoaded', () => {
    loadStats();
    loadContacts();
    loadOrders();
    loadPortfolios();
    loadUsers();  // ADD THIS
    
    setupTechInput();
});
```

**Tambah function loadUsers:**
```javascript
// Load users
async function loadUsers() {
    try {
        const response = await fetch('/api/admin/users');
        const users = await response.json();
        
        const tbody = document.getElementById('usersTableBody');
        
        if (users.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="empty-state">No users yet</td></tr>';
            return;
        }
        
        tbody.innerHTML = users.map(user => `
            <tr>
                <td><strong>${user.name}</strong></td>
                <td>${user.email}</td>
                <td>${user.phone}</td>
                <td>${new Date(user.createdAt).toLocaleDateString('id-ID')}</td>
                <td>
                    <div class="action-btns">
                        <button class="action-btn btn-delete" onclick="deleteUser(${user.id})">Delete</button>
                    </div>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading users:', error);
    }
}

// Delete user
async function deleteUser(id) {
    if (!confirm('Delete this user? This will also delete their orders and messages.')) return;
    
    try {
        const response = await fetch(`/api/admin/users/${id}`, { method: 'DELETE' });
        const data = await response.json();
        
        if (data.success) {
            loadUsers();
            loadStats();
            alert('User deleted!');
        }
    } catch (error) {
        console.error('Error deleting user:', error);
        alert('Error deleting user');
    }
}
```

✅ DONE! User management ready.

---

### 4️⃣ LIVE CHAT UI (5 menit)

**File:** `views/user-dashboard.html`

**A. Tambah Chat Tab:**
```html
<div class="tabs">
    <button class="tab active" onclick="switchTab('orders')">My Orders</button>
    <button class="tab" onclick="switchTab('contacts')">My Messages</button>
    <button class="tab" onclick="switchTab('newOrder')">New Order</button>
    <button class="tab" onclick="switchTab('chat')">💬 Chat</button> <!-- ADD THIS -->
</div>
```

**B. Tambah Chat Content** (setelah newOrderTab):
```html
<!-- Chat Tab -->
<div id="chatTab" class="tab-content">
    <div class="table-container" style="height: 600px; display: flex; flex-direction: column;">
        <div class="table-header">
            <h2>💬 Chat with Admin</h2>
        </div>
        <div id="chatMessages" style="flex: 1; overflow-y: auto; padding: 20px; background: #f9f9f9;">
            <div class="empty-state">Loading messages...</div>
        </div>
        <div style="padding: 20px; border-top: 1px solid #e0e0e0; background: white;">
            <div style="display: flex; gap: 10px;">
                <input type="text" id="chatInput" placeholder="Type your message..." 
                       style="flex: 1; padding: 12px; border: 2px solid #e0e0e0; border-radius: 5px;"
                       onkeypress="if(event.key==='Enter') sendMessage()">
                <button onclick="sendMessage()" class="btn-submit" style="padding: 12px 24px;">Send</button>
            </div>
        </div>
    </div>
</div>
```

**C. Tambah CSS** (di section <style>):
```css
.chat-message {
    margin-bottom: 15px;
    padding: 12px 16px;
    border-radius: 12px;
    max-width: 70%;
}

.chat-message.user {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    margin-left: auto;
    text-align: right;
}

.chat-message.admin {
    background: white;
    border: 2px solid #e0e0e0;
    margin-right: auto;
}

.chat-time {
    font-size: 11px;
    opacity: 0.7;
    margin-top: 5px;
}
```

**File:** `public/js/user-dashboard.js`

**Tambah di DOMContentLoaded:**
```javascript
document.addEventListener('DOMContentLoaded', () => {
    loadProfile();
    loadStats();
    loadOrders();
    loadContacts();
    loadChats();  // ADD THIS
    
    setupOrderForm();
    setupContactForm();
    
    // Auto-refresh chat
    setInterval(loadChats, 5000);  // ADD THIS
});
```

**Tambah functions:**
```javascript
// Load chats
async function loadChats() {
    try {
        const response = await fetch('/api/chats');
        const chats = await response.json();
        
        const chatMessages = document.getElementById('chatMessages');
        
        if (chats.length === 0) {
            chatMessages.innerHTML = '<div class="empty-state">No messages yet. Start a conversation!</div>';
            return;
        }
        
        chatMessages.innerHTML = chats.map(chat => `
            <div class="chat-message ${chat.sender}">
                <div style="font-weight: 600; margin-bottom: 5px;">${chat.sender === 'user' ? 'You' : 'Admin'}</div>
                <div>${chat.message}</div>
                <div class="chat-time">${new Date(chat.timestamp).toLocaleString('id-ID', {
                    hour: '2-digit',
                    minute: '2-digit',
                    day: 'numeric',
                    month: 'short'
                })}</div>
            </div>
        `).join('');
        
        // Scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    } catch (error) {
        console.error('Error loading chats:', error);
    }
}

// Send message
async function sendMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    try {
        const response = await fetch('/api/chats', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message })
        });
        
        const data = await response.json();
        
        if (data.success) {
            input.value = '';
            loadChats();
        }
    } catch (error) {
        console.error('Error sending message:', error);
    }
}
```

**File:** `views/admin.html` - Admin Chat Tab

**A. Tambah Tab:**
```html
<button class="tab" onclick="switchTab('adminChat')">💬 Chat</button>
```

**B. Tambah Content:**
```html
<!-- Admin Chat Tab -->
<div id="adminChatTab" class="tab-content">
    <div style="display: grid; grid-template-columns: 300px 1fr; height: 600px;">
        <!-- User List -->
        <div style="border-right: 1px solid #e0e0e0; overflow-y: auto; background: #f9f9f9;">
            <div style="padding: 20px; border-bottom: 1px solid #e0e0e0; background: white;">
                <h3>Conversations</h3>
            </div>
            <div id="chatUserList">
                <div class="empty-state">No chats yet</div>
            </div>
        </div>
        
        <!-- Messages -->
        <div style="display: flex; flex-direction: column;">
            <div id="adminChatHeader" style="padding: 20px; border-bottom: 1px solid #e0e0e0; background: white;">
                <h3>Select a conversation</h3>
            </div>
            <div id="adminChatMessages" style="flex: 1; overflow-y: auto; padding: 20px;">
                <div class="empty-state">Select a user</div>
            </div>
            <div id="adminChatInput" style="padding: 20px; border-top: 1px solid #e0e0e0; display: none;">
                <div style="display: flex; gap: 10px;">
                    <input type="text" id="adminMessageInput" placeholder="Reply..." 
                           style="flex: 1; padding: 12px; border: 2px solid #e0e0e0; border-radius: 5px;">
                    <button onclick="sendAdminMessage()" class="btn-submit">Send</button>
                </div>
            </div>
        </div>
    </div>
</div>
```

**File:** `public/js/admin.js`

**Tambah variable:**
```javascript
let currentChatUserId = null;
```

**Tambah di DOMContentLoaded:**
```javascript
loadAdminChats();  // ADD THIS
setInterval(() => {
    if (currentChatUserId) loadAdminChats();
}, 5000);  // ADD THIS
```

**Tambah functions:**
```javascript
// Load admin chats
async function loadAdminChats() {
    try {
        const response = await fetch('/api/admin/chats');
        const chatsByUser = await response.json();
        
        const chatList = document.getElementById('chatUserList');
        
        if (chatsByUser.length === 0) {
            chatList.innerHTML = '<div class="empty-state">No chats</div>';
            return;
        }
        
        chatList.innerHTML = chatsByUser.map(chat => `
            <div style="padding: 15px; border-bottom: 1px solid #e0e0e0; cursor: pointer;" 
                 onclick="openUserChat(${chat.userId})">
                <div style="font-weight: 600;">${chat.userName} 
                    ${chat.unreadCount > 0 ? `<span style="background: #f44336; color: white; padding: 2px 8px; border-radius: 10px; font-size: 11px;">${chat.unreadCount}</span>` : ''}
                </div>
                <div style="font-size: 12px; color: #666;">${chat.userEmail}</div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading chats:', error);
    }
}

// Open user chat
async function openUserChat(userId) {
    currentChatUserId = userId;
    await fetch(`/api/admin/chats/${userId}/read`, { method: 'PUT' });
    loadAdminChats();
    document.getElementById('adminChatInput').style.display = 'block';
}

// Send admin message
async function sendAdminMessage() {
    const input = document.getElementById('adminMessageInput');
    const message = input.value.trim();
    
    if (!message || !currentChatUserId) return;
    
    try {
        const response = await fetch('/api/admin/chats', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId: currentChatUserId, message })
        });
        
        if (response.ok) {
            input.value = '';
            loadAdminChats();
        }
    } catch (error) {
        console.error('Error:', error);
    }
}
```

✅ DONE! Chat fully functional.

---

## 🎯 RESTART PM2

Setelah semua update:

```bash
pm2 reload website-agency
# atau
pm2 restart website-agency
```

---

## ✅ TESTING CHECKLIST

- [ ] Homepage portfolio section muncul
- [ ] Admin bisa input preview URL saat add/edit portfolio
- [ ] Admin tab "Users" menampilkan registered users
- [ ] Admin bisa delete user
- [ ] User bisa chat dengan admin
- [ ] Admin bisa reply chat user
- [ ] Chat auto-refresh setiap 5 detik
- [ ] PM2 tidak auto-restart lagi

---

## 🐛 TROUBLESHOOTING

**Chat tidak muncul?**
```bash
# Check API
curl http://localhost:611/api/chats

# Check console browser (F12)
```

**PM2 masih restart?**
```bash
# Monitor
pm2 monit

# Check logs
pm2 logs website-agency
```

---

## 📞 QUICK COMMANDS

```bash
# Restart PM2
pm2 restart website-agency

# Monitor
pm2 monit

# Logs
pm2 logs

# Status
pm2 list
```

**Semua fitur siap! Tinggal copy-paste code di atas ke file yang sesuai!**
