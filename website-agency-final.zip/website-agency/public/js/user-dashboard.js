// Load initial data
document.addEventListener('DOMContentLoaded', () => {
    loadProfile();
    loadStats();
    loadOrders();
    loadContacts();
    
    // Setup form handlers
    setupOrderForm();
    setupContactForm();
});

// Load user profile
async function loadProfile() {
    try {
        const response = await fetch('/api/user/profile');
        const data = await response.json();
        
        if (data.success) {
            document.getElementById('userName').textContent = data.user.name;
            document.getElementById('welcomeText').textContent = `Selamat Datang, ${data.user.name}!`;
        }
    } catch (error) {
        console.error('Error loading profile:', error);
    }
}

// Load statistics
async function loadStats() {
    try {
        const response = await fetch('/api/user/stats');
        const stats = await response.json();
        
        document.getElementById('statOrders').textContent = stats.totalOrders;
        document.getElementById('statPending').textContent = stats.pendingOrders;
        document.getElementById('statCompleted').textContent = stats.completedOrders;
        document.getElementById('statContacts').textContent = stats.totalContacts;
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Load orders
async function loadOrders() {
    try {
        const response = await fetch('/api/user/orders');
        const orders = await response.json();
        
        const tbody = document.getElementById('ordersTableBody');
        
        if (orders.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="empty-state">Belum ada order</td></tr>';
            return;
        }
        
        tbody.innerHTML = orders.map(order => `
            <tr>
                <td>${new Date(order.timestamp).toLocaleDateString('id-ID')}</td>
                <td><strong>${order.package}</strong></td>
                <td>${order.requirements}</td>
                <td><span class="status-badge status-${order.status}">${order.status}</span></td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading orders:', error);
    }
}

// Load contacts
async function loadContacts() {
    try {
        const response = await fetch('/api/user/contacts');
        const contacts = await response.json();
        
        const tbody = document.getElementById('contactsTableBody');
        
        if (contacts.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="empty-state">Belum ada pesan</td></tr>';
            return;
        }
        
        tbody.innerHTML = contacts.map(contact => `
            <tr>
                <td>${new Date(contact.timestamp).toLocaleDateString('id-ID')}</td>
                <td>${contact.package || '-'}</td>
                <td>${contact.message}</td>
                <td><span class="status-badge status-${contact.status}">${contact.status}</span></td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading contacts:', error);
    }
}

// Tab switching
function switchTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    event.target.classList.add('active');
    
    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    document.getElementById(tabName + 'Tab').classList.add('active');
}

// Setup order form
function setupOrderForm() {
    document.getElementById('orderForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const packageType = document.getElementById('orderPackage').value;
        const requirements = document.getElementById('orderRequirements').value;
        
        const successMsg = document.getElementById('orderSuccessMessage');
        const errorMsg = document.getElementById('orderErrorMessage');
        
        successMsg.style.display = 'none';
        errorMsg.style.display = 'none';
        
        try {
            const response = await fetch('/api/user/order', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    package: packageType,
                    requirements: requirements
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                successMsg.textContent = data.message;
                successMsg.style.display = 'block';
                
                // Reset form
                document.getElementById('orderForm').reset();
                
                // Reload data
                loadStats();
                loadOrders();
                
                // Switch to orders tab after 2 seconds
                setTimeout(() => {
                    document.querySelector('.tab').click();
                }, 2000);
            } else {
                errorMsg.textContent = data.message || 'Terjadi kesalahan';
                errorMsg.style.display = 'block';
            }
        } catch (error) {
            console.error('Error submitting order:', error);
            errorMsg.textContent = 'Terjadi kesalahan. Silakan coba lagi.';
            errorMsg.style.display = 'block';
        }
    });
}

// Setup contact form
function setupContactForm() {
    document.getElementById('contactForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const packageType = document.getElementById('contactPackage').value;
        const message = document.getElementById('contactMessage').value;
        
        const successMsg = document.getElementById('contactSuccessMessage');
        const errorMsg = document.getElementById('contactErrorMessage');
        
        successMsg.style.display = 'none';
        errorMsg.style.display = 'none';
        
        try {
            const response = await fetch('/api/user/contact', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    package: packageType,
                    message: message
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                successMsg.textContent = data.message;
                successMsg.style.display = 'block';
                
                // Reset form
                document.getElementById('contactForm').reset();
                
                // Reload data
                loadStats();
                loadContacts();
                
                // Scroll to success message
                successMsg.scrollIntoView({ behavior: 'smooth', block: 'center' });
            } else {
                errorMsg.textContent = data.message || 'Terjadi kesalahan';
                errorMsg.style.display = 'block';
            }
        } catch (error) {
            console.error('Error submitting contact:', error);
            errorMsg.textContent = 'Terjadi kesalahan. Silakan coba lagi.';
            errorMsg.style.display = 'block';
        }
    });
}

// Logout
function logout() {
    if (confirm('Apakah Anda yakin ingin logout?')) {
        window.location.href = '/user/logout';
    }
}
