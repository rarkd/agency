require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const session = require('express-session');

const app = express();
const PORT = process.env.PORT || 611;

// Database JSON file path
const DB_PATH = path.join(__dirname, 'database.json');

// Helper functions for database
function readDatabase() {
  try {
    const data = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading database:', error);
    return null;
  }
}

function writeDatabase(data) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('Error writing database:', error);
    return false;
  }
}

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(session({
  secret: 'website-agency-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 3600000 } // 1 hour
}));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Load database
let database = readDatabase();

// Authentication middleware
function isAuthenticated(req, res, next) {
  if (req.session.isAuthenticated) {
    return next();
  }
  res.redirect('/admin/login');
}

// Routes
app.get('/', (req, res) => {
  const db = readDatabase();
  res.render('index', { 
    portfolios: db.portfolios.slice(0, 6),
    packages: db.packages
  });
});

app.get('/portfolio', (req, res) => {
  const db = readDatabase();
  res.render('portfolio', { portfolios: db.portfolios });
});

app.get('/pricing', (req, res) => {
  const db = readDatabase();
  res.render('pricing', { packages: db.packages });
});

app.get('/contact', (req, res) => {
  res.render('contact');
});

// Admin routes
app.get('/admin/login', (req, res) => {
  if (req.session.isAuthenticated) {
    return res.redirect('/admin');
  }
  res.sendFile(path.join(__dirname, 'views', 'admin-login.html'));
});

app.post('/admin/login', (req, res) => {
  const { username, password } = req.body;
  const db = readDatabase();
  
  if (username === db.admin.username && password === db.admin.password) {
    req.session.isAuthenticated = true;
    req.session.username = username;
    res.json({ success: true });
  } else {
    res.json({ success: false, message: 'Username atau password salah' });
  }
});

app.get('/admin/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/admin/login');
});

app.get('/admin', isAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'admin.html'));
});

// API Endpoints
app.get('/api/portfolios', (req, res) => {
  const db = readDatabase();
  res.json(db.portfolios);
});

app.get('/api/packages', (req, res) => {
  const db = readDatabase();
  res.json(db.packages);
});

app.get('/api/admin/contacts', isAuthenticated, (req, res) => {
  const db = readDatabase();
  res.json(db.contacts);
});

app.get('/api/admin/orders', isAuthenticated, (req, res) => {
  const db = readDatabase();
  res.json(db.orders);
});

app.get('/api/admin/stats', isAuthenticated, (req, res) => {
  const db = readDatabase();
  res.json({
    totalContacts: db.contacts.length,
    totalOrders: db.orders.length,
    totalPortfolios: db.portfolios.length,
    pendingOrders: db.orders.filter(o => o.status === 'pending').length
  });
});

// Contact form submission
app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, phone, package: packageType, message } = req.body;
    const db = readDatabase();
    
    const newContact = {
      id: Date.now(),
      name,
      email,
      phone,
      package: packageType,
      message,
      timestamp: new Date().toISOString(),
      status: 'new'
    };
    
    db.contacts.push(newContact);
    
    if (writeDatabase(db)) {
      console.log('Contact form submission:', newContact);
      res.json({ 
        success: true, 
        message: 'Terima kasih! Kami akan segera menghubungi Anda.' 
      });
    } else {
      throw new Error('Failed to save contact');
    }
  } catch (error) {
    console.error('Error saving contact:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Terjadi kesalahan. Silakan coba lagi.' 
    });
  }
});

// Order endpoint
app.post('/api/order', async (req, res) => {
  try {
    const { name, email, phone, package: packageType, requirements } = req.body;
    const db = readDatabase();
    
    const newOrder = {
      id: Date.now(),
      name,
      email,
      phone,
      package: packageType,
      requirements,
      status: 'pending',
      timestamp: new Date().toISOString()
    };
    
    db.orders.push(newOrder);
    
    if (writeDatabase(db)) {
      console.log('Order submission:', newOrder);
      res.json({ 
        success: true, 
        message: 'Order berhasil! Tim kami akan menghubungi Anda segera.' 
      });
    } else {
      throw new Error('Failed to save order');
    }
  } catch (error) {
    console.error('Error saving order:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Terjadi kesalahan. Silakan coba lagi.' 
    });
  }
});

// Admin CRUD operations for portfolios
app.post('/api/admin/portfolios', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    const newPortfolio = {
      id: Date.now(),
      ...req.body
    };
    db.portfolios.push(newPortfolio);
    if (writeDatabase(db)) {
      res.json({ success: true, data: newPortfolio });
    } else {
      throw new Error('Failed to save portfolio');
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.put('/api/admin/portfolios/:id', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    const index = db.portfolios.findIndex(p => p.id == req.params.id);
    if (index !== -1) {
      db.portfolios[index] = { ...db.portfolios[index], ...req.body };
      if (writeDatabase(db)) {
        res.json({ success: true, data: db.portfolios[index] });
      } else {
        throw new Error('Failed to update portfolio');
      }
    } else {
      res.status(404).json({ success: false, message: 'Portfolio not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.delete('/api/admin/portfolios/:id', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    db.portfolios = db.portfolios.filter(p => p.id != req.params.id);
    if (writeDatabase(db)) {
      res.json({ success: true });
    } else {
      throw new Error('Failed to delete portfolio');
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Update contact/order status
app.put('/api/admin/contacts/:id', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    const index = db.contacts.findIndex(c => c.id == req.params.id);
    if (index !== -1) {
      db.contacts[index] = { ...db.contacts[index], ...req.body };
      if (writeDatabase(db)) {
        res.json({ success: true, data: db.contacts[index] });
      } else {
        throw new Error('Failed to update contact');
      }
    } else {
      res.status(404).json({ success: false, message: 'Contact not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.delete('/api/admin/contacts/:id', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    db.contacts = db.contacts.filter(c => c.id != req.params.id);
    if (writeDatabase(db)) {
      res.json({ success: true });
    } else {
      throw new Error('Failed to delete contact');
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.put('/api/admin/orders/:id', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    const index = db.orders.findIndex(o => o.id == req.params.id);
    if (index !== -1) {
      db.orders[index] = { ...db.orders[index], ...req.body };
      if (writeDatabase(db)) {
        res.json({ success: true, data: db.orders[index] });
      } else {
        throw new Error('Failed to update order');
      }
    } else {
      res.status(404).json({ success: false, message: 'Order not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.delete('/api/admin/orders/:id', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    db.orders = db.orders.filter(o => o.id != req.params.id);
    if (writeDatabase(db)) {
      res.json({ success: true });
    } else {
      throw new Error('Failed to delete order');
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// 404 handler
app.use((req, res) => {
  res.status(404).render('404');
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});
