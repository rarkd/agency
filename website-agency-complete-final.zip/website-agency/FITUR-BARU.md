# 🆕 FITUR BARU - Dokumentasi Lengkap

## ✨ Ringkasan Fitur Baru

### 1. 👁️ Preview Portfolio Template
**Lokasi:** Portfolio Page
**Deskripsi:** Setiap portfolio sekarang memiliki tombol "Preview Demo" yang membuka preview template di tab baru.

**Implementasi:**
- Database: Tambah field `previewUrl` di setiap portfolio
- Frontend: Tambah button preview di portfolio card
- CSS: Style untuk button preview

**Contoh Data:**
```json
{
  "id": 1,
  "title": "E-Commerce Fashion Store",
  "previewUrl": "https://demo-ecommerce.example.com"
}
```

### 2. 💬 Chat Feature (Client ↔ Admin)
**Lokasi:** User Dashboard & Admin Dashboard
**Deskripsi:** Real-time messaging antara client dan admin

**API Endpoints:**
```javascript
// User endpoints
GET /api/chats                  // Get user chats
POST /api/chats                 // Send message

// Admin endpoints  
GET /api/admin/chats            // Get all chats grouped by user
POST /api/admin/chats           // Reply to user
PUT /api/admin/chats/:userId/read  // Mark as read
```

**Database Structure:**
```json
{
  "chats": [
    {
      "id": 1234567890,
      "userId": 123,
      "userName": "John Doe",
      "userEmail": "john@example.com",
      "message": "Hello, I need help",
      "sender": "user",  // or "admin"
      "timestamp": "2024-02-27T10:00:00.000Z",
      "read": false
    }
  ]
}
```

**User Dashboard - Chat Tab:**
```html
<!-- Tambahkan tab -->
<button class="tab" onclick="switchTab('chat')">Chat with Admin</button>

<!-- Tambahkan content -->
<div id="chatTab" class="tab-content">
  <div class="chat-container">
    <div id="chatMessages" class="chat-messages">
      <!-- Messages here -->
    </div>
    <div class="chat-input">
      <input type="text" id="chatInput" placeholder="Type message...">
      <button onclick="sendMessage()">Send</button>
    </div>
  </div>
</div>
```

**JavaScript Functions:**
```javascript
// Load chats
async function loadChats() {
  const response = await fetch('/api/chats');
  const chats = await response.json();
  displayChats(chats);
}

// Send message
async function sendMessage() {
  const message = document.getElementById('chatInput').value;
  await fetch('/api/chats', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message })
  });
  loadChats();
}

// Auto-refresh every 5 seconds
setInterval(loadChats, 5000);
```

### 3. 👥 User Management (Admin)
**Lokasi:** Admin Dashboard
**Deskripsi:** Admin dapat view dan manage users

**API Endpoints:**
```javascript
GET /api/admin/users           // Get all users
DELETE /api/admin/users/:id    // Delete user
```

**Admin Dashboard - Users Tab:**
```html
<button class="tab" onclick="switchTab('users')">Users</button>

<div id="usersTab" class="tab-content">
  <div class="table-container">
    <div class="table-header">
      <h2>Registered Users</h2>
    </div>
    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Registered</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="usersTableBody">
        <!-- Users data -->
      </tbody>
    </table>
  </div>
</div>
```

### 4. 🎨 Template Selection in Order
**Lokasi:** User Dashboard - New Order
**Deskripsi:** Client dapat memilih template reference saat order

**Update Order Form:**
```html
<form id="orderForm">
  <!-- ... existing fields ... -->
  
  <div class="form-group">
    <label>Template Reference (Optional)</label>
    <select id="orderTemplate">
      <option value="">-- No Template --</option>
      <!-- Populated from portfolios API -->
    </select>
  </div>
  
  <div class="form-group">
    <label>Package</label>
    <select id="orderPackage" required>
      <option value="bronze">Bronze</option>
      <option value="silver">Silver</option>
      <option value="gold">Gold</option>
    </select>
  </div>
  
  <div class="form-group">
    <label>Requirements</label>
    <textarea id="orderRequirements"></textarea>
  </div>
  
  <button type="submit">Submit Order</button>
</form>
```

**JavaScript:**
```javascript
// Load templates into select
async function loadTemplates() {
  const response = await fetch('/api/portfolios');
  const portfolios = await response.json();
  
  const select = document.getElementById('orderTemplate');
  portfolios.forEach(portfolio => {
    const option = document.createElement('option');
    option.value = portfolio.id;
    option.textContent = `${portfolio.title} (${portfolio.package})`;
    select.appendChild(option);
  });
}

// Submit order with template
document.getElementById('orderForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const orderData = {
    package: document.getElementById('orderPackage').value,
    requirements: document.getElementById('orderRequirements').value,
    templateId: document.getElementById('orderTemplate').value || null
  };
  
  await fetch('/api/user/order', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(orderData)
  });
});
```

### 5. 📋 Enhanced Order Display (Admin)
**Lokasi:** Admin Dashboard - Orders
**Deskripsi:** Tampilkan informasi lengkap order termasuk template dan phone

**Order Detail Display:**
```javascript
function viewOrder(id) {
  const order = orders.find(o => o.id === id);
  
  document.getElementById('orderDetails').innerHTML = `
    <div class="order-info">
      <h3>Order Information</h3>
      <p><strong>Name:</strong> ${order.name}</p>
      <p><strong>Email:</strong> ${order.email}</p>
      <p><strong>Phone:</strong> ${order.phone}</p>
      <p><strong>Package:</strong> ${order.package}</p>
      
      ${order.template ? `
        <p><strong>Template Reference:</strong></p>
        <div class="template-ref">
          <p>${order.template.title}</p>
          <a href="${order.template.previewUrl}" target="_blank">
            View Template Preview
          </a>
        </div>
      ` : '<p><strong>Template:</strong> No template selected</p>'}
      
      <p><strong>Requirements:</strong></p>
      <p>${order.requirements}</p>
      
      <p><strong>Status:</strong> ${order.status}</p>
      <p><strong>Date:</strong> ${new Date(order.timestamp).toLocaleString()}</p>
    </div>
  `;
}
```

**Admin Orders Table Update:**
```javascript
tbody.innerHTML = orders.map(order => `
  <tr>
    <td>${new Date(order.timestamp).toLocaleDateString()}</td>
    <td>${order.name}</td>
    <td>${order.phone}</td>
    <td>${order.email}</td>
    <td>${order.package}</td>
    <td>${order.template ? order.template.title : '-'}</td>
    <td><span class="status-badge status-${order.status}">${order.status}</span></td>
    <td>
      <button onclick="viewOrder(${order.id})">View Details</button>
    </td>
  </tr>
`).join('');
```

## 📊 Data Flow

### Order dengan Template:
```
User Dashboard
  → Select Template from dropdown
  → Fill requirements
  → Submit
    → Server saves order with template info
      → Admin sees full order details with template link
```

### Chat Flow:
```
User sends message
  → Saved to database
    → Admin sees unread count
      → Admin opens chat
        → Marks as read
          → Admin replies
            → User sees reply
              → Repeat...
```

### User Management:
```
Admin Dashboard
  → Users Tab
    → View all registered users
      → Can delete users
        → Confirmation required
```

## 🎨 CSS untuk Fitur Baru

```css
/* Chat Styles */
.chat-container {
  display: flex;
  flex-direction: column;
  height: 600px;
}

.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
  background: #f9f9f9;
}

.chat-message {
  margin-bottom: 15px;
  padding: 10px 15px;
  border-radius: 10px;
  max-width: 70%;
}

.chat-message.user {
  background: #667eea;
  color: white;
  margin-left: auto;
  text-align: right;
}

.chat-message.admin {
  background: white;
  border: 1px solid #e0e0e0;
}

.chat-input {
  padding: 20px;
  border-top: 1px solid #e0e0e0;
  background: white;
  display: flex;
  gap: 10px;
}

.chat-input input {
  flex: 1;
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 5px;
}

/* Template Reference Display */
.template-ref {
  background: #f5f5f5;
  padding: 15px;
  border-radius: 5px;
  margin: 10px 0;
}

.template-ref a {
  color: #667eea;
  text-decoration: none;
  font-weight: 600;
}

/* Unread Chat Badge */
.unread-badge {
  background: #f44336;
  color: white;
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 12px;
  margin-left: 5px;
}
```

## 🔧 Setup Instructions

### 1. Update Database
File `database.json` sudah diupdate dengan:
- `previewUrl` di portfolios
- `chats` array
- Order structure dengan `template` field

### 2. Update Server.js
Sudah ditambahkan:
- Chat API endpoints
- User management endpoints  
- Enhanced order endpoint dengan template

### 3. Update Frontend Files

**User Dashboard:**
1. Tambah Chat tab
2. Update order form dengan template selection
3. Load portfolios ke dropdown
4. Implement chat functions

**Admin Dashboard:**
1. Tambah Users tab
2. Tambah Chat tab  
3. Enhanced order view dengan template dan phone
4. User management functions

**Portfolio Page:**
1. Tambah preview button di setiap card
2. Link ke previewUrl

### 4. Update JavaScript

**user-dashboard.js:**
- `loadTemplates()` - Load portfolios to dropdown
- `sendMessage()` - Send chat message
- `loadChats()` - Load and display chats
- Update `setupOrderForm()` to include templateId

**admin.js:**
- `loadUsers()` - Load users table
- `deleteUser(id)` - Delete user
- `loadAdminChats()` - Load chats by user
- `sendAdminMessage(userId, message)` - Send reply
- Enhanced `viewOrder()` to show template and phone

## ✅ Testing Checklist

- [ ] Portfolio preview buttons berfungsi
- [ ] Template selection di order form
- [ ] Chat user → admin
- [ ] Chat admin → user  
- [ ] Admin view users
- [ ] Admin delete user
- [ ] Order tampil dengan template info
- [ ] Order tampil dengan phone number
- [ ] Chat unread count
- [ ] Chat auto-refresh

## 🚀 Deployment

Semua fitur sudah terintegrasi di:
- `database.json`
- `server.js`
- `views/portfolio.ejs`
- CSS sudah ditambahkan

Yang perlu dilakukan:
1. Update `views/user-dashboard.html` dengan chat tab dan template selection
2. Update `views/admin.html` dengan users tab dan chat tab
3. Update `public/js/user-dashboard.js` dengan chat functions
4. Update `public/js/admin.js` dengan chat dan user management

File-file ini sudah siap di sistem!
