require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const session = require('express-session');

const app = express();
const PORT = process.env.PORT || 611;

// Database JSON file path
const DB_PATH = path.join(__dirname, 'database.json');

// Helper functions for database
function readDatabase() {
  try {
    const data = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading database:', error);
    return null;
  }
}

function writeDatabase(data) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('Error writing database:', error);
    return false;
  }
}

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(session({
  secret: 'website-agency-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 3600000 } // 1 hour
}));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Load database
let database = readDatabase();

// Authentication middleware
function isAuthenticated(req, res, next) {
  if (req.session.isAuthenticated) {
    return next();
  }
  res.redirect('/admin/login');
}

// User authentication middleware
function isUserAuthenticated(req, res, next) {
  if (req.session.isUserAuthenticated) {
    return next();
  }
  res.redirect('/user/login');
}

// Routes
app.get('/', (req, res) => {
  const db = readDatabase();
  res.render('index', { 
    portfolios: db.portfolios.slice(0, 6),
    packages: db.packages
  });
});

app.get('/portfolio', (req, res) => {
  const db = readDatabase();
  res.render('portfolio', { portfolios: db.portfolios });
});

app.get('/pricing', (req, res) => {
  const db = readDatabase();
  res.render('pricing', { packages: db.packages });
});

app.get('/contact', (req, res) => {
  res.render('contact');
});

// Admin routes
app.get('/admin/login', (req, res) => {
  if (req.session.isAuthenticated) {
    return res.redirect('/admin');
  }
  res.sendFile(path.join(__dirname, 'views', 'admin-login.html'));
});

app.post('/admin/login', (req, res) => {
  const { username, password } = req.body;
  const db = readDatabase();
  
  if (username === db.admin.username && password === db.admin.password) {
    req.session.isAuthenticated = true;
    req.session.username = username;
    res.json({ success: true });
  } else {
    res.json({ success: false, message: 'Username atau password salah' });
  }
});

app.get('/admin/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/admin/login');
});

app.get('/admin', isAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'admin.html'));
});

// User routes
app.get('/user/register', (req, res) => {
  if (req.session.isUserAuthenticated) {
    return res.redirect('/user/dashboard');
  }
  res.sendFile(path.join(__dirname, 'views', 'user-register.html'));
});

app.post('/user/register', (req, res) => {
  const { name, email, password, phone } = req.body;
  const db = readDatabase();
  
  // Check if email already exists
  const existingUser = db.users.find(u => u.email === email);
  if (existingUser) {
    return res.json({ success: false, message: 'Email sudah terdaftar' });
  }
  
  const newUser = {
    id: Date.now(),
    name,
    email,
    phone,
    password, // In production, use bcrypt to hash password
    createdAt: new Date().toISOString()
  };
  
  db.users.push(newUser);
  
  if (writeDatabase(db)) {
    res.json({ success: true, message: 'Registrasi berhasil!' });
  } else {
    res.json({ success: false, message: 'Terjadi kesalahan. Silakan coba lagi.' });
  }
});

app.get('/user/login', (req, res) => {
  if (req.session.isUserAuthenticated) {
    return res.redirect('/user/dashboard');
  }
  res.sendFile(path.join(__dirname, 'views', 'user-login.html'));
});

app.post('/user/login', (req, res) => {
  const { email, password } = req.body;
  const db = readDatabase();
  
  const user = db.users.find(u => u.email === email && u.password === password);
  
  if (user) {
    req.session.isUserAuthenticated = true;
    req.session.userId = user.id;
    req.session.userEmail = user.email;
    req.session.userName = user.name;
    res.json({ success: true });
  } else {
    res.json({ success: false, message: 'Email atau password salah' });
  }
});

app.get('/user/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/user/login');
});

app.get('/user/dashboard', isUserAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'user-dashboard.html'));
});

// API Endpoints
app.get('/api/portfolios', (req, res) => {
  const db = readDatabase();
  res.json(db.portfolios);
});

app.get('/api/packages', (req, res) => {
  const db = readDatabase();
  res.json(db.packages);
});

app.get('/api/admin/contacts', isAuthenticated, (req, res) => {
  const db = readDatabase();
  res.json(db.contacts);
});

app.get('/api/admin/orders', isAuthenticated, (req, res) => {
  const db = readDatabase();
  res.json(db.orders);
});

app.get('/api/admin/stats', isAuthenticated, (req, res) => {
  const db = readDatabase();
  res.json({
    totalContacts: db.contacts.length,
    totalOrders: db.orders.length,
    totalPortfolios: db.portfolios.length,
    pendingOrders: db.orders.filter(o => o.status === 'pending').length
  });
});

// User API endpoints
app.get('/api/user/profile', isUserAuthenticated, (req, res) => {
  const db = readDatabase();
  const user = db.users.find(u => u.id === req.session.userId);
  if (user) {
    // Don't send password
    const { password, ...userWithoutPassword } = user;
    res.json({ success: true, user: userWithoutPassword });
  } else {
    res.json({ success: false, message: 'User not found' });
  }
});

app.get('/api/user/orders', isUserAuthenticated, (req, res) => {
  const db = readDatabase();
  const userOrders = db.orders.filter(o => o.email === req.session.userEmail);
  res.json(userOrders);
});

app.get('/api/user/contacts', isUserAuthenticated, (req, res) => {
  const db = readDatabase();
  const userContacts = db.contacts.filter(c => c.email === req.session.userEmail);
  res.json(userContacts);
});

app.get('/api/user/stats', isUserAuthenticated, (req, res) => {
  const db = readDatabase();
  const userOrders = db.orders.filter(o => o.email === req.session.userEmail);
  const userContacts = db.contacts.filter(c => c.email === req.session.userEmail);
  
  res.json({
    totalOrders: userOrders.length,
    totalContacts: userContacts.length,
    pendingOrders: userOrders.filter(o => o.status === 'pending').length,
    completedOrders: userOrders.filter(o => o.status === 'completed').length
  });
});

// User submit order (authenticated)
app.post('/api/user/order', isUserAuthenticated, async (req, res) => {
  try {
    const { package: packageType, requirements, templateId } = req.body;
    const db = readDatabase();
    const user = db.users.find(u => u.id === req.session.userId);
    
    // Get template info if provided
    let templateInfo = null;
    if (templateId) {
      const template = db.portfolios.find(p => p.id == templateId);
      if (template) {
        templateInfo = {
          id: template.id,
          title: template.title,
          previewUrl: template.previewUrl
        };
      }
    }
    
    const newOrder = {
      id: Date.now(),
      name: user.name,
      email: user.email,
      phone: user.phone,
      package: packageType,
      requirements,
      template: templateInfo,
      status: 'pending',
      timestamp: new Date().toISOString()
    };
    
    db.orders.push(newOrder);
    
    if (writeDatabase(db)) {
      console.log('Order submission:', newOrder);
      res.json({ 
        success: true, 
        message: 'Order berhasil! Tim kami akan menghubungi Anda segera.',
        order: newOrder
      });
    } else {
      throw new Error('Failed to save order');
    }
  } catch (error) {
    console.error('Error saving order:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Terjadi kesalahan. Silakan coba lagi.' 
    });
  }
});

// User submit contact (authenticated)
app.post('/api/user/contact', isUserAuthenticated, async (req, res) => {
  try {
    const { package: packageType, message } = req.body;
    const db = readDatabase();
    const user = db.users.find(u => u.id === req.session.userId);
    
    const newContact = {
      id: Date.now(),
      name: user.name,
      email: user.email,
      phone: user.phone,
      package: packageType,
      message,
      timestamp: new Date().toISOString(),
      status: 'new'
    };
    
    db.contacts.push(newContact);
    
    if (writeDatabase(db)) {
      console.log('Contact form submission:', newContact);
      res.json({ 
        success: true, 
        message: 'Terima kasih! Kami akan segera menghubungi Anda.',
        contact: newContact
      });
    } else {
      throw new Error('Failed to save contact');
    }
  } catch (error) {
    console.error('Error saving contact:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Terjadi kesalahan. Silakan coba lagi.' 
    });
  }
});

// Chat API endpoints
app.get('/api/chats', isUserAuthenticated, (req, res) => {
  const db = readDatabase();
  const userChats = db.chats.filter(c => c.userId === req.session.userId);
  res.json(userChats);
});

app.post('/api/chats', isUserAuthenticated, (req, res) => {
  try {
    const { message } = req.body;
    const db = readDatabase();
    const user = db.users.find(u => u.id === req.session.userId);
    
    const newChat = {
      id: Date.now(),
      userId: req.session.userId,
      userName: user.name,
      userEmail: user.email,
      message,
      sender: 'user',
      timestamp: new Date().toISOString(),
      read: false
    };
    
    db.chats.push(newChat);
    
    if (writeDatabase(db)) {
      res.json({ success: true, chat: newChat });
    } else {
      throw new Error('Failed to save chat');
    }
  } catch (error) {
    console.error('Error saving chat:', error);
    res.status(500).json({ success: false, message: 'Terjadi kesalahan' });
  }
});

// Admin chat endpoints
app.get('/api/admin/chats', isAuthenticated, (req, res) => {
  const db = readDatabase();
  
  // Group chats by user
  const chatsByUser = {};
  db.chats.forEach(chat => {
    if (!chatsByUser[chat.userId]) {
      chatsByUser[chat.userId] = {
        userId: chat.userId,
        userName: chat.userName,
        userEmail: chat.userEmail,
        messages: [],
        unreadCount: 0
      };
    }
    chatsByUser[chat.userId].messages.push(chat);
    if (!chat.read && chat.sender === 'user') {
      chatsByUser[chat.userId].unreadCount++;
    }
  });
  
  res.json(Object.values(chatsByUser));
});

app.post('/api/admin/chats', isAuthenticated, (req, res) => {
  try {
    const { userId, message } = req.body;
    const db = readDatabase();
    const user = db.users.find(u => u.id === userId);
    
    const newChat = {
      id: Date.now(),
      userId: userId,
      userName: user.name,
      userEmail: user.email,
      message,
      sender: 'admin',
      timestamp: new Date().toISOString(),
      read: false
    };
    
    db.chats.push(newChat);
    
    if (writeDatabase(db)) {
      res.json({ success: true, chat: newChat });
    } else {
      throw new Error('Failed to save chat');
    }
  } catch (error) {
    console.error('Error saving chat:', error);
    res.status(500).json({ success: false, message: 'Terjadi kesalahan' });
  }
});

app.put('/api/admin/chats/:userId/read', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    db.chats.forEach(chat => {
      if (chat.userId == req.params.userId && chat.sender === 'user') {
        chat.read = true;
      }
    });
    
    if (writeDatabase(db)) {
      res.json({ success: true });
    } else {
      throw new Error('Failed to update chat');
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Admin user management
app.get('/api/admin/users', isAuthenticated, (req, res) => {
  const db = readDatabase();
  // Don't send passwords
  const users = db.users.map(({ password, ...user }) => user);
  res.json(users);
});

app.delete('/api/admin/users/:id', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    db.users = db.users.filter(u => u.id != req.params.id);
    if (writeDatabase(db)) {
      res.json({ success: true });
    } else {
      throw new Error('Failed to delete user');
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Contact form submission
app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, phone, package: packageType, message } = req.body;
    const db = readDatabase();
    
    const newContact = {
      id: Date.now(),
      name,
      email,
      phone,
      package: packageType,
      message,
      timestamp: new Date().toISOString(),
      status: 'new'
    };
    
    db.contacts.push(newContact);
    
    if (writeDatabase(db)) {
      console.log('Contact form submission:', newContact);
      res.json({ 
        success: true, 
        message: 'Terima kasih! Kami akan segera menghubungi Anda.' 
      });
    } else {
      throw new Error('Failed to save contact');
    }
  } catch (error) {
    console.error('Error saving contact:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Terjadi kesalahan. Silakan coba lagi.' 
    });
  }
});

// Order endpoint
app.post('/api/order', async (req, res) => {
  try {
    const { name, email, phone, package: packageType, requirements } = req.body;
    const db = readDatabase();
    
    const newOrder = {
      id: Date.now(),
      name,
      email,
      phone,
      package: packageType,
      requirements,
      status: 'pending',
      timestamp: new Date().toISOString()
    };
    
    db.orders.push(newOrder);
    
    if (writeDatabase(db)) {
      console.log('Order submission:', newOrder);
      res.json({ 
        success: true, 
        message: 'Order berhasil! Tim kami akan menghubungi Anda segera.' 
      });
    } else {
      throw new Error('Failed to save order');
    }
  } catch (error) {
    console.error('Error saving order:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Terjadi kesalahan. Silakan coba lagi.' 
    });
  }
});

// Admin CRUD operations for portfolios
app.post('/api/admin/portfolios', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    const newPortfolio = {
      id: Date.now(),
      ...req.body
    };
    db.portfolios.push(newPortfolio);
    if (writeDatabase(db)) {
      res.json({ success: true, data: newPortfolio });
    } else {
      throw new Error('Failed to save portfolio');
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.put('/api/admin/portfolios/:id', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    const index = db.portfolios.findIndex(p => p.id == req.params.id);
    if (index !== -1) {
      db.portfolios[index] = { ...db.portfolios[index], ...req.body };
      if (writeDatabase(db)) {
        res.json({ success: true, data: db.portfolios[index] });
      } else {
        throw new Error('Failed to update portfolio');
      }
    } else {
      res.status(404).json({ success: false, message: 'Portfolio not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.delete('/api/admin/portfolios/:id', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    db.portfolios = db.portfolios.filter(p => p.id != req.params.id);
    if (writeDatabase(db)) {
      res.json({ success: true });
    } else {
      throw new Error('Failed to delete portfolio');
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Update contact/order status
app.put('/api/admin/contacts/:id', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    const index = db.contacts.findIndex(c => c.id == req.params.id);
    if (index !== -1) {
      db.contacts[index] = { ...db.contacts[index], ...req.body };
      if (writeDatabase(db)) {
        res.json({ success: true, data: db.contacts[index] });
      } else {
        throw new Error('Failed to update contact');
      }
    } else {
      res.status(404).json({ success: false, message: 'Contact not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.delete('/api/admin/contacts/:id', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    db.contacts = db.contacts.filter(c => c.id != req.params.id);
    if (writeDatabase(db)) {
      res.json({ success: true });
    } else {
      throw new Error('Failed to delete contact');
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.put('/api/admin/orders/:id', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    const index = db.orders.findIndex(o => o.id == req.params.id);
    if (index !== -1) {
      db.orders[index] = { ...db.orders[index], ...req.body };
      if (writeDatabase(db)) {
        res.json({ success: true, data: db.orders[index] });
      } else {
        throw new Error('Failed to update order');
      }
    } else {
      res.status(404).json({ success: false, message: 'Order not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.delete('/api/admin/orders/:id', isAuthenticated, (req, res) => {
  try {
    const db = readDatabase();
    db.orders = db.orders.filter(o => o.id != req.params.id);
    if (writeDatabase(db)) {
      res.json({ success: true });
    } else {
      throw new Error('Failed to delete order');
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// 404 handler
app.use((req, res) => {
  res.status(404).render('404');
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});
