# 📱 USER DASHBOARD DOCUMENTATION

## 🎯 Overview

User Dashboard adalah portal untuk client/pelanggan Website Agency dimana mereka dapat:
- ✅ Registrasi akun baru
- ✅ Login ke dashboard pribadi
- ✅ Melihat order yang pernah dibuat
- ✅ Melihat riwayat pesan/contact
- ✅ Submit order baru dari dashboard
- ✅ Kirim pesan ke admin
- ✅ Track status order (pending, processing, completed)

## 🔗 URLs User Dashboard

### Public Pages:
- **Register:** http://localhost:611/user/register
- **Login:** http://localhost:611/user/login

### Protected Pages (require login):
- **Dashboard:** http://localhost:611/user/dashboard

## 📝 Cara Menggunakan User Dashboard

### 1. Registrasi Akun Baru

1. Buka http://localhost:611/user/register
2. Isi form:
   - Nama Lengkap
   - Email
   - No. Telepon
   - Password (minimal 6 karakter)
   - Konfirmasi Password
3. Klik "Daftar Sekarang"
4. Jika berhasil, akan redirect ke halaman login

### 2. Login ke Dashboard

1. Buka http://localhost:611/user/login
2. Masukkan email dan password
3. Klik "Login"
4. Akan redirect ke dashboard

### 3. Menggunakan Dashboard

#### Overview Statistics
Dashboard menampilkan statistik:
- Total Orders: Jumlah order yang pernah dibuat
- Pending Orders: Order yang masih pending
- Completed: Order yang sudah selesai
- Messages Sent: Jumlah pesan yang dikirim

#### Tab "My Orders"
Menampilkan semua order yang pernah dibuat dengan informasi:
- Tanggal order
- Package yang dipilih
- Requirements/kebutuhan
- Status order (pending/processing/completed)

#### Tab "My Messages"
Menampilkan semua pesan yang pernah dikirim dengan informasi:
- Tanggal kirim
- Package terkait (jika ada)
- Isi pesan
- Status (new/read)

#### Tab "New Order"
Form untuk submit order baru:
1. Pilih package (Bronze/Silver/Gold)
2. Isi requirements/kebutuhan website
3. Klik "Submit Order"
4. Order akan masuk ke sistem dan admin akan dihubungi

Form untuk kirim pesan:
1. Pilih package terkait (opsional)
2. Tulis pesan
3. Klik "Send Message"

## 🗄️ Database Structure

### User Object
```json
{
  "id": 1709123456789,
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "08123456789",
  "password": "encrypted_password",
  "createdAt": "2024-02-27T10:30:00.000Z"
}
```

### Orders & Contacts
Orders dan contacts yang dibuat oleh user akan otomatis ter-link dengan email user.

## 🔐 Security Features

### Session Management
- User session disimpan di server
- Session berbeda dengan admin session
- Auto logout jika session expired

### Session Variables
```javascript
req.session.isUserAuthenticated  // true/false
req.session.userId              // user ID
req.session.userEmail          // user email
req.session.userName           // user name
```

### Authentication Middleware
```javascript
function isUserAuthenticated(req, res, next) {
  if (req.session.isUserAuthenticated) {
    return next();
  }
  res.redirect('/user/login');
}
```

## 🔌 API Endpoints

### Authentication
```
POST /user/register
Body: { name, email, phone, password }
Response: { success: true/false, message }

POST /user/login
Body: { email, password }
Response: { success: true/false, message }

GET /user/logout
Response: Redirect to /user/login
```

### User Data
```
GET /api/user/profile
Response: { success: true, user: {...} }

GET /api/user/stats
Response: {
  totalOrders,
  totalContacts,
  pendingOrders,
  completedOrders
}

GET /api/user/orders
Response: [array of user orders]

GET /api/user/contacts
Response: [array of user contacts]
```

### Submit Data
```
POST /api/user/order
Body: { package, requirements }
Response: { success: true/false, message, order }

POST /api/user/contact
Body: { package, message }
Response: { success: true/false, message, contact }
```

## 📁 File Structure

```
website-agency/
├── views/
│   ├── user-register.html     ← Registration page
│   ├── user-login.html         ← Login page
│   └── user-dashboard.html     ← Dashboard page
├── public/js/
│   └── user-dashboard.js       ← Dashboard JavaScript
├── database.json               ← User data stored here
└── server.js                   ← User routes & API
```

## 🎨 UI Features

### Responsive Design
- Dashboard fully responsive
- Mobile-friendly navigation
- Touch-optimized for tablets

### Color Scheme
- Primary: #667eea (Purple)
- Secondary: #764ba2 (Dark Purple)
- Success: #4caf50 (Green)
- Warning: #ff9800 (Orange)
- Error: #f44336 (Red)

## 🔄 User Flow

```
Homepage → Click "Login"
    ↓
New User? → Register → Login → Dashboard
    ↓
Existing User? → Login → Dashboard
    ↓
Dashboard → View Orders/Messages
         → Submit New Order
         → Send Message
```

## 🆚 User Dashboard vs Admin Dashboard

| Feature | User Dashboard | Admin Dashboard |
|---------|---------------|-----------------|
| URL | /user/dashboard | /admin |
| Login | /user/login | /admin/login |
| View Orders | Own orders only | All orders |
| Submit Order | ✅ Yes | ❌ No |
| Edit Order Status | ❌ No | ✅ Yes |
| Delete Order | ❌ No | ✅ Yes |
| View Contacts | Own messages only | All messages |
| Portfolio CRUD | ❌ No | ✅ Yes |

## 🔧 Customization

### Change Session Duration
Edit `server.js`:
```javascript
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { 
    secure: false, 
    maxAge: 3600000  // 1 hour (change this)
  }
}));
```

### Add Password Encryption
Install bcrypt:
```bash
npm install bcrypt
```

Update registration:
```javascript
const bcrypt = require('bcrypt');

// On register
const hashedPassword = await bcrypt.hash(password, 10);

// On login
const match = await bcrypt.compare(password, user.password);
```

## 🐛 Troubleshooting

### User tidak bisa login
- Check email dan password correct
- Check session configuration
- Clear browser cookies

### Order/Contact tidak muncul
- Check email match antara user dan order
- Reload data dengan F5
- Check browser console untuk error

### Session expired terus
- Increase maxAge di session config
- Check cookie settings
- Pastikan browser accept cookies

## ✅ Testing Checklist

- [ ] Register user baru
- [ ] Login dengan user yang sudah terdaftar
- [ ] View statistics di dashboard
- [ ] View orders list (should be empty for new user)
- [ ] Submit new order dari dashboard
- [ ] Check order muncul di "My Orders"
- [ ] Submit new message
- [ ] Check message muncul di "My Messages"
- [ ] Logout dan login lagi
- [ ] Check data masih ada setelah logout
- [ ] Test di mobile browser
- [ ] Test admin dapat melihat user orders

## 🚀 Next Steps / Future Enhancements

Potential improvements:
- [ ] Email verification on registration
- [ ] Password reset functionality
- [ ] Profile edit page
- [ ] Upload files/documents
- [ ] Real-time notifications
- [ ] Payment integration
- [ ] Chat with admin
- [ ] Order tracking timeline
- [ ] Download invoice

## 📞 Support

Jika ada pertanyaan atau masalah:
1. Check dokumentasi ini
2. Check browser console untuk errors
3. Check server logs
4. Contact: admin@websiteagency.com

---

**Happy Coding! 🎉**
